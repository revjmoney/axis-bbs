AXIS Micro BBS SD card kit
by Rev. J. Money / jmscnc.com

For a first install. Copy everything in this zip to the root of the board's SD card
(FAT32), keeping the folders:
  scripts/     programs for the Scripts door and SCRIPT: menu commands
Nothing here holds users, messages or settings; those live on the board.
