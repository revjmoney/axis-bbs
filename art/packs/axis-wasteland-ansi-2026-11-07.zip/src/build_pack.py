#!/usr/bin/env python3
"""Axis Micro BBS - underground ANSI pack generator (reproducible, no randomness without seed).
Writes 80-col CP437 .ANS files using classic 16-colour SGR only (30-37/40-47 + bold for bright fg).
Run:  python3 build_pack.py   (outputs ../ans/*.ans)"""
import math,os,random
V2A=[0,4,2,6,1,5,3,7]   # VGA colour index -> ANSI SGR digit
W=80
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')

# ---------------- 5x8 display font (each pixel = 2 columns x 1 half-row) -------------
F={
'A':[".###.","#...#","#...#","#####","#...#","#...#","#...#","#...#"],
'X':["#...#","#...#",".#.#.","..#..","..#..",".#.#.","#...#","#...#"],
'I':["#####","..#..","..#..","..#..","..#..","..#..","..#..","#####"],
'S':[".####","#....","#....",".###.","....#","....#","....#","####."],
'M':["#...#","##.##","#.#.#","#.#.#","#...#","#...#","#...#","#...#"],
'T':["#####","..#..","..#..","..#..","..#..","..#..","..#..","..#.."],
'R':["####.","#...#","#...#","####.","#.#..","#..#.","#...#","#...#"],
'D':["####.","#...#","#...#","#...#","#...#","#...#","#...#","####."],
'O':[".###.","#...#","#...#","#...#","#...#","#...#","#...#",".###."],
'L':["#....","#....","#....","#....","#....","#....","#....","#####"],
'G':[".###.","#...#","#....","#....","#.###","#...#","#...#",".###."],
'N':["#...#","##..#","##..#","#.#.#","#.#.#","#..##","#..##","#...#"],
'P':["####.","#...#","#...#","####.","#....","#....","#....","#...."],
'Y':["#...#","#...#",".#.#.","..#..","..#..","..#..","..#..","..#.."],
'F':["#####","#....","#....","####.","#....","#....","#....","#...."],
'E':["#####","#....","#....","####.","#....","#....","#....","#####"],
'C':[".###.","#...#","#....","#....","#....","#....","#...#",".###."],
'H':["#...#","#...#","#...#","#####","#...#","#...#","#...#","#...#"],
'U':["#...#","#...#","#...#","#...#","#...#","#...#","#...#",".###."],
'W':["#...#","#...#","#...#","#.#.#","#.#.#","#.#.#","##.##","#...#"],
'B':["####.","#...#","#...#","####.","#...#","#...#","#...#","####."],
}
THEMES={ # face ramp: 4 (bright,dark) pairs top->bottom; accent; texture colours
 'steel':  dict(r=[15,7,11,3,9,1,8,0],  acc=11,warm=14,t1=1,t2=8),
 'violet': dict(r=[15,7,13,5,9,1,8,0],  acc=13,warm=14,t1=5,t2=1),
 'ember':  dict(r=[15,7,14,6,12,4,13,5],acc=14,warm=12,t1=5,t2=1),
 'acid':   dict(r=[15,7,11,3,10,2,9,1], acc=10,warm=14,t1=2,t2=1),
 'ice':    dict(r=[15,7,11,3,9,1,13,5], acc=11,warm=14,t1=1,t2=5),
}
def dark(c): return 0 if c==8 else (c-8 if c>7 else c)

class Canvas:
    def __init__(s,rows,tex):
        s.R=rows;s.cell=[[None]*W for _ in range(rows)];s.px=[[None]*W for _ in range(rows*2)];s.tex=tex;s.blank=set()
    def p(s,hy,x,c):
        if 0<=hy<s.R*2 and 0<=x<W: s.px[hy][x]=c
    def put(s,y,x,text,fg,bg=0):
        for i,ch in enumerate(text):
            if 0<=x+i<W and 0<=y<s.R: s.cell[y][x+i]=(ch,fg,bg)
    def clear(s,y0,y1,x0,x1):   # black window, removes pixels & texture
        for y in range(y0,y1+1):
            for x in range(x0,x1+1):
                s.cell[y][x]=None;s.px[2*y][x]=s.px[2*y+1][x]=None;s.blank.add((y,x))
    def final(s):
        g=[]
        for y in range(s.R):
            row=[]
            for x in range(W):
                if s.cell[y][x] is not None: row.append(s.cell[y][x]);continue
                t,b=s.px[2*y][x],s.px[2*y+1][x]
                if t is None and b is None: row.append((' ',7,0) if (y,x) in s.blank else s.tex(x,y))
                elif t==b: row.append(('█',t,0))
                elif b is None: row.append(('▀',t,0))
                elif t is None: row.append(('▄',b,0))
                elif b<=7: row.append(('▀',t,b))
                elif t<=7: row.append(('▄',b,t))
                else: row.append(('▀',t,dark(b)))
            g.append(row)
        return g

def logo(cv,word,x0,hy0,th,sx=2,sy=1,slant=True,shadow=True):
    """Extruded italic logo: far shadow layer, near shadow layer, ramp-shaded face, edge highlights."""
    r=th['r'];H=8*sy
    pts={}
    cx=x0
    for ch in word:
        if ch==' ': cx+=3*sx;continue
        bm=F[ch]
        for fy,line in enumerate(bm):
            for fx,v in enumerate(line):
                if v=='#':
                    for yy in range(sy):
                        hy=fy*sy+yy; off=((7-fy)//3)*(sx//2 or 1) if slant else 0
                        for xx in range(sx): pts[(hy,cx+fx*sx+xx+off)]=1
        cx+=5*sx+3
    if shadow:
        for (hy,x) in pts: cv.p(hy0+hy+2,x+2,th['t2'] if th['t2'] not in (0,8) else 1)  # far extrusion layer
        for (hy,x) in pts: cv.p(hy0+hy+1,x+1,8)                                         # near extrusion layer
    for (hy,x) in pts:
        c=r[min(7,hy*8//H)]
        if (hy-1,x) not in pts: c=15 if hy*8//H<5 else th['acc']   # top-lit bevel highlight
        if (hy+1,x) not in pts and hy*8//H>=4: c=r[7] if r[7]!=0 else 8
        cv.p(hy0+hy,x,c)
    return cx

def plate_tex(th,seed):
    """Diagonal brushed-steel back plate with stepped ░▒▓ ramps and rivet dots."""
    def f(x,y):
        band=((x+2*y+seed)//7)%4
        if (x*7+y*13+seed)%53==0: return ('·',th['acc'],0)
        return [(' ',7,0),(' ',7,0),(' ',7,0),('░',th['t2'],0)][band] if y<5 else [(' ',7,0),('░',th['t2'],0),(' ',7,0),('░',th['t1'],0)][band]
    return f

def ramp_bar(cv,y,th,x0=1,x1=78):
    """Stepped dark-to-light tube: ░▒▓█ shading into theme colours, brand-gold core."""
    n=x1-x0+1
    for i in range(n):
        d=min(i,n-1-i); 
        seq=[('░',8),('▒',8),('▓',8),('░',th['t1']+8 if th['t1']<8 else th['t1']),('▒',th['t1']+8),('▓',th['t1']+8),('█',th['t1']+8),('▓',th['acc']),('█',th['acc'])]
        if d<len(seq)*3: ch,c=seq[d//3]
        else: ch,c=('▀',14) if (i//2)%2 else ('▀',6)
        bg=th['t1'] if ch=='▀' else 0
        cv.put(y,x0+i,ch,c,bg)

def pillar(cv,y0,y1,x,th):
    for y in range(y0,y1+1):
        k=(y-y0)%5
        if k==0: cv.put(y,x,'▄▄',8);cv.put(y,x+1,'▄',th['acc'])
        elif k==1: cv.put(y,x,'█',7);cv.put(y,x+1,'▌',th['acc'],0)
        else: cv.put(y,x,['▓','▒','░'][k-2],th['t1']+8 if th['t1']<8 else 9);cv.put(y,x+1,'▒',8)

# ---------------- procedural sprites on the half-row pixel grid -------------------
def sp_gear(cv,cx,cy,R,th,teeth=10):
    for hy in range(int(cy-R-3),int(cy+R+4)):
        for x in range(int(cx-2*R-6),int(cx+2*R+7)):
            dx=(x-cx)/2.0;dy=hy-cy;d=math.hypot(dx,dy);a=math.atan2(dy,dx)
            tooth=math.cos(a*teeth)>0.2
            if d<R*0.35: continue
            if d<R or (tooth and d<R+2.2):
                lit=(-dx-dy)/(d+.01)
                c=15 if lit>0.6 else 7 if lit>0.1 else th['acc'] if lit>-0.4 else 8
                if R*0.35<=d<R*0.5: c=th['t1']+8 if th['t1']<8 else 9
                cv.p(hy,x,c)
def sp_endmill(cv,x,hy,th):
    for i in range(22):
        for j in range(6):
            if i<9: c=[7,15,15,7,8,8][j]
            else: c=[14,15,6,6,14,8][(j+i)%6] if j in (0,1,2,3,4) else 8
            if i>=20 and j in (0,5): continue
            cv.p(hy+i,x+j,c)
    for k in range(6): cv.p(hy+23+k%3,x-4+k*3,th['warm'])  # chips
def sp_door(cv,x,hy,th):
    for i in range(22):
        for j in range(14):
            edge=i in (0,1) or j in (0,1,12,13)
            c=8 if edge else ([th['t1'],th['t1']+8 if th['t1']<8 else 9][(i//4)%2] if j<12 else 8)
            if 2<=i<=20 and 3<=j<=10 and (i in (3,10,11,19) or j in (3,10)): c=7
            cv.p(hy+i,x+j,c)
    cv.p(hy+11,x+11,14);cv.p(hy+12,x+11,6)
    for i in range(22): cv.p(hy+i,x+15,th['warm'] if i%3 else 6)   # light leak
def sp_key(cv,x,hy,th):
    for hy2 in range(-5,6):
        for x2 in range(-10,11):
            d=math.hypot(x2/2,hy2)
            if 2.2<d<5: cv.p(hy+6+hy2,x+10+x2,14 if hy2<0 else 6)
    for j in range(20,34): cv.p(hy+5,x+j,15);cv.p(hy+6,x+j,7)
    for j in (28,32): cv.p(hy+7,x+j,7);cv.p(hy+8,x+j,7)
def sp_env(cv,x,hy,th):
    for i in range(14):
        for j in range(20):
            c=7 if i>0 else 15
            if abs(j-9.5)*0.7<=i<=abs(j-9.5)*0.7+1: c=th['acc']
            cv.p(hy+i,x+j,c)
    cv.p(hy+7,x+9,12);cv.p(hy+7,x+10,12)
def sp_floppy(cv,x,hy,th):
    for i in range(18):
        for j in range(18):
            c=th['t1']+8 if th['t1']<8 else 9
            if 1<=i<=6 and 4<=j<=13: c=7 if j!=10 else 0
            if 10<=i<=17 and 3<=j<=14: c=15 if i>11 else 7
            if i==0 or j==0: c=15
            cv.p(hy+i,x+j,c)
def sp_bolt(cv,x,hy,th):
    pts=[(0,10),(4,8),(8,6),(10,12),(14,9),(18,6),(22,3)]
    for i in range(23):
        w=10-i//3 if i<11 else 8-(i-11)//2
        off=10-int(i*0.5) if i<11 else 14-int((i-11)*0.8)
        for j in range(max(1,w//2)): cv.p(hy+i,x+off+j,15 if j==0 else th['warm'] if j<2 else 12)
def sp_grid(cv,x,hy,th):
    for i in range(22):
        for j in range(16):
            if i%4==0 or j%4==0: cv.p(hy+i,x+j,th['acc'] if (i+j)%8 else 15)
            elif (i*3+j*5)%7==0: cv.p(hy+i,x+j,2)
def sp_form(cv,x,hy,th):
    for i in range(22):
        for j in range(15):
            c=15 if i<2 else 7
            if i>3 and i%3==0 and 2<=j<=12-(i%2)*3: c=8
            cv.p(hy+i,x+j,c)
    for j in range(5,10): cv.p(hy,x+j,6);cv.p(hy+1,x+j,14)
    for k in range(8): cv.p(hy+18-k,x+14+k,th['warm']);cv.p(hy+19-k,x+14+k,6)

def tagline(cv,y,x):
    cv.put(y,x,'u',8);cv.put(y,x+1,'.g',6);cv.put(y,x+3,'. c',8);cv.put(y,x+6,'n',15);cv.put(y,x+7,'c',8)

def screen(key,title,theme,sprite,texts,seed):
    th=THEMES[theme];cv=Canvas(24,plate_tex(th,seed))
    # header back plate rows 1-5 textured; logo spans half-rows 0-9 (+shadow)
    end=logo(cv,title.upper(),3,0,th,slant=False)
    tagline(cv,4,min(71,end+1))
    # title row 6 (row index 5) - brand strip
    for x in range(W): cv.put(5,x,'▄' if x%2 else '▀',8,0)
    cv.put(5,1,'▄▀▄ ',6);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',6)
    cv.put(5,10+len(title),' ░▒▓',th['t1']+8 if th['t1']<8 else 9)
    ramp_bar(cv,6,th)            # row 7
    cv.clear(7,20,2,77)            # dynamic content window rows 8-21, cols 3-78
    pillar(cv,7,21,0,th);pillar(cv,7,21,78,th)
    # inner frame corners (layered)
    cv.put(7,2,'▄▄▄',8);cv.put(7,75,'▄▄▄',8);cv.put(20,2,'▀▀▀',8);cv.put(20,75,'▀▀▀',8)
    if sprite: sprite(cv,60,22,th)    # half-row 22 = text row 12
    cv.clear(21,21,2,77)
    # footer rows 23-24: chip-strewn floor with stepped ramp and brand
    for x in range(W):
        h=(math.sin(x*0.37+seed)+math.sin(x*0.11))*1.2
        for hy in range(44,48):
            if hy>=45+h*0.6: cv.p(hy,x,[8,th['t1'],8,0][hy-44] if hy<47 else 0)
    for x in range(W): cv.put(23,x,'░▒▓█▓▒░ '[x%8] if x<16 or x>63 else ' ',8 if x<16 or x>63 else 7)
    cv.put(23,18,' A X I S   M I C R O   B B S ',7);cv.put(23,48,' u.g. cnc ',6);cv.put(23,49,'u',14)
    return cv,th,texts

# ======================= v2 body art: machinery backdrop, sculpted gear, layered sprites ==========
def lit(v):            # 0..1 light value -> steel ramp colour
    return [0,8,7,15][max(0,min(3,int(v*4)))]
def sp_gear2(cv,cx,cy,R,th,teeth=12,hole=True):
    """Sculpted gear: drop shadow layer, black outline, bevelled rim lit from top-left, recessed web, hub+bolts."""
    def inside(dx,dy):
        d=math.hypot(dx,dy);a=math.atan2(dy,dx)
        tooth=math.cos(a*teeth)>0.15
        return d<R or (tooth and d<R*1.22)
    box=range(int(cy-R*1.3)-2,int(cy+R*1.3)+3),range(int(cx-R*1.3)-3,int(cx+R*1.3)+4)
    for hy in box[0]:                     # layer 1: cast shadow (down-right), layer 2: outline
        for x in box[1]:
            if inside((x-cx-3),hy-cy-2): cv.p(hy,x,th['t1'])
    for hy in box[0]:
        for x in box[1]:
            dx=(x-cx);dy=hy-cy;d=math.hypot(dx,dy)
            if not inside(dx,dy):
                if any(inside((x+ox-cx),hy+oy-cy) for ox,oy in ((-1,0),(1,0),(0,1),(0,-1))): cv.p(hy,x,0)
                continue
            nx,ny=dx/(d+.01),dy/(d+.01);L=-(nx*0.7+ny*0.7)
            if d>=R*0.98:   c=[8,8,7,15][max(0,min(3,int((0.5+0.5*L)*4)))]                 # tooth flanks
            elif d>R*0.8:  c=[8,8,7,15][max(0,min(3,int((0.45+0.55*L)*4)))]                # outer rim bevel
            elif d>R*0.72: c=lit(0.35-0.4*L)                 # rim inner wall (inverse lit = recess)
            elif d>R*0.38:
                c=8
                hx,hyv=dx,dy
                for k in range(4):
                    ang=k*math.pi/2+math.pi/4;px_,py_=math.cos(ang)*R*0.56,math.sin(ang)*R*0.56
                    if math.hypot(dx-px_,dy-py_)<R*0.13: c=0
                    elif math.hypot(dx-px_,dy-py_)<R*0.19: c=7 if (dy-py_)>0 else 0
            elif d>R*0.3: c=lit(0.6-0.5*L)
            elif d>R*0.16: c=lit(0.5+0.5*L) if d>R*0.22 else th['acc']
            else: c=0
            if 0.8*R<d<R and L>0.9: c=15   # edge glint
            cv.p(hy,x,c)
def layered(cv,fn,x,hy,th,scale=1):
    """Draw a sprite through two silhouette layers: offset dark shadow, then 1px black outline, then face."""
    tmp=Canvas(cv.R,lambda a,b:(' ',7,0));fn(tmp,0,0,th)
    pts={(y,xx):c for y,r in enumerate(tmp.px) for xx,c in enumerate(r) if c is not None}
    if scale!=1:
        pts={(int(y*scale)+dy,int(xx*scale)+dx):c for (y,xx),c in pts.items() for dy in range(int(scale+0.99)) for dx in range(int(scale+0.99))}
    for (y,xx) in pts: cv.p(hy+y+2,x+xx+2,th['t1'] if th['t1']<8 else 1)
    for (y,xx) in pts:
        for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
            if (y+oy,xx+ox) not in pts: cv.p(hy+y+oy,x+xx+ox,0)
    for (y,xx),c in pts.items(): cv.p(hy+y,x+xx,c)
def pipe_h(cv,hy,x0,x1,th):
    ramp=[0,8,7,15,7,8,th['t1'],0]
    for i,c in enumerate(ramp):
        for x in range(x0,x1+1): cv.p(hy+i,x,c)
    for x in range(x0+3,x1,9):                      # flanges with glints
        for i in range(-1,9): cv.p(hy+i,x,[0,8,7,15,15,7,8,8,th['t1'],0][i+1]); cv.p(hy+i,x+1,8 if 0<=i<8 else 0)
        cv.p(hy+2,x,th['warm'])
def pipe_v(cv,x,hy0,hy1,th):
    ramp=[0,8,7,15,15,7,8,0]
    for hy in range(hy0,hy1+1):
        for i,c in enumerate(ramp): cv.p(hy,x+i,c)
    for hy in range(hy0+2,hy1,7):
        for i in range(-1,9): cv.p(hy,x+i,[0,7,15,15,15,7,8,8,8,0][i+1])
def traces(cv,x0,x1,hy0,hy1,th,seed):
    rnd=random.Random(seed)
    for k in range((x1-x0)*(hy1-hy0)//60):
        x=rnd.randrange(x0,x1);y=rnd.randrange(hy0,hy1)
        L=rnd.randrange(4,14);hor=rnd.random()<0.6
        for t in range(L):
            xx,yy=(x+t,y) if hor else (x,y+t)
            if x0<=xx<=x1 and hy0<=yy<=hy1 and cv.px[yy][xx] is None: cv.p(yy,xx,th['t1'] if th['t1']<8 else 1)
        if x0<=xx<=x1 and hy0<=yy<=hy1: cv.p(yy,xx,th['acc'])
def body_tex(th,seed,top):
    def f(x,y):
        if y<5: return plate_tex(th,seed)(x,y)
        if y==top: return ('▀',8,0)
        k=((x//10)+(y//4))%2
        if (x%10==0) or (y%4==0): return ('░',8,0) if k else ('▒',8,0)
        if (x*7+y*3)%23==0: return ('·',th['acc'],0)
        return ('░',1,0) if k else (' ',7,0)
    return f
def plate(cv,y0,y1,x0,x1,th):
    """Recessed black text plate: bevel lit top-left, dark bottom-right, so labels stay readable."""
    cv.clear(y0,y1,x0,x1)
    for x in range(x0-1,x1+2): cv.put(y0-1,x,'▄',7 if x<(x0+x1)//2 else 8);cv.put(y1+1,x,'▀',8 if x<(x0+x1)//2 else th['t1'] if th['t1']<8 else 1)
    for y in range(y0,y1+1): cv.put(y,x0-1,'▐',7);cv.put(y,x1+1,'▌',8)
    cv.put(y0-1,x0-1,'▄',15);cv.put(y1+1,x1+1,'▀',0)

def screen(key,title,theme,sprite,texts,seed,menu):
    th=THEMES[theme];cv=Canvas(24,body_tex(th,seed,7))
    end=logo(cv,title.upper(),3,0,th,slant=False)
    tagline(cv,4,min(71,end+1))
    for x in range(W): cv.put(5,x,'▄' if x%2 else '▀',8,0)
    cv.put(5,1,'▄▀▄ ',6);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',6)
    cv.put(5,10+len(title),' ░▒▓',th['t1']+8 if th['t1']<8 else 9)
    ramp_bar(cv,6,th)
    pillar(cv,7,21,0,th);pillar(cv,7,21,78,th)
    # machinery backdrop: circuit traces + cylindrical pipes (half-row pixel layer)
    traces(cv,2,77,16,43,th,seed)
    if menu:
        pipe_v(cv,46,15,43,th);pipe_h(cv,34,54,77,th)
        sp_gear2(cv,67,21,8,th,teeth=10)
        layered(cv,sprite,52,26,th,scale=1)
        plate(cv,8,20,3,43,th)          # documented dynamic menu window rows 9-21, cols 4-44
        cv.clear(21,21,3,43)
    else:
        pipe_h(cv,38,2,77,th);pipe_v(cv,40,16,37,th)
        sp_gear2(cv,66,23,10,th,teeth=12)
        layered(cv,sprite,45,20,th,scale=1.2)
        rows=[r for r,_,_,_ in texts]
        w=max(len(t) for _,_,_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        plate(cv,min(rows)-1,max(rows)-1,3,3+w,th)
    # footer
    for x in range(W):
        h=(math.sin(x*0.37+seed)+math.sin(x*0.11))*1.2
        for hy in range(44,48):
            if hy>=45+h*0.6: cv.p(hy,x,[8,th['t1'],8,0][hy-44] if hy<47 else 0)
    for x in range(W): cv.put(23,x,'░▒▓█▓▒░ '[x%8] if x<16 or x>63 else ' ',8 if x<16 or x>63 else 7)
    cv.put(23,18,' A X I S   M I C R O   B B S ',7);cv.put(23,48,' u.g. cnc ',6);cv.put(23,49,'u',14)
    return cv,th,texts

def emit(g,full=True,tail=''):
    out=['\x1b[0m'];st=None
    if full: out.append('\x1b[2J\x1b[H')
    for y,row in enumerate(g):
        if full: out.append('\x1b[%d;1H'%(y+1))
        n=W-1 if (y==len(g)-1 or not full) else W   # never write column 80 on last row / inline rows
        for ch,fg,bg in row[:n]:
            if ch==' ' and bg==0 and st and st[1]==0: out.append(' ');continue
            assert 0<=bg<=7 and 0<=fg<=15; s=(fg,bg)
            if s!=st:
                out.append('\x1b[0;%s3%d;4%dm'%('1;' if fg>7 else '',V2A[fg&7],V2A[bg]));st=s
            out.append(ch)
        if not full and y<len(g)-1: out.append('\x1b[0m\r\n');st=None
    out.append('\x1b[0m');out.append(tail)
    return ''.join(out).encode('cp437')

def big_screen(rows,inline):
    th=THEMES['steel'];random.seed(7)
    def tex(x,y):
        if (x*31+y*17)%97==0: return ('·',15,0)
        if (x*13+y*7)%61==0: return ('∙',9,0)
        if y<rows*0.45: return [(' ',7,0),(' ',7,0),('░',1,0),(' ',7,0)][((x+3*y)//9)%4]
        return (' ',7,0)
    cv=Canvas(rows,tex)
    if not inline:
        # perspective floor grid (vanishing point) rows 15-23
        vx,vy=40,26
        vy=24
        for hy in (29,31,34,38,43):
            for x in range(W): cv.p(hy,x,13 if hy>=38 else 5)
        for i in range(-14,15):
            for hy in range(28,48):
                x=int(round(vx+i*(hy-vy)*0.55))
                if 0<=x<W: cv.p(hy,x,13 if hy>=38 else 5)
        for x in range(W): cv.p(27,x,9 if x%2 else 1)   # horizon glow
    hy=1 if inline else 4
    logo(cv,'AXIS',8,hy,th,sx=3,sy=2)
    # orbiting ring layer behind logo, drawn only where empty (overlap trick)
    for t in range(0,720):
        a=t/720*2*math.pi;x=int(40+36*math.cos(a));y=int(hy+8+7*math.sin(a))
        if cv.px[y][x] is None if 0<=y<rows*2 else False:
            cv.p(y,x,14 if math.sin(a)>0 else 6)
    return cv,th

SCREENS=[
 # key,title,theme,sprite,texts(row,col,fg,text), original hash
 ('axis_welcome','axis','steel',sp_gear,[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('axis_main_menu','axis','ice',sp_gear,[(22,4,8,'arrows move, Enter picks, or press the key')],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('login','login','violet',sp_key,[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('apply_new_user','apply','acid',sp_form,[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('doors_menu','doors','ember',sp_door,[(22,4,8,'arrows move, Enter picks, or press the key')],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('messages_menu','msgs','violet',sp_env,[(22,4,8,'arrows move, Enter picks, or press the key')],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('files_menu','files','steel',sp_floppy,[(22,4,8,'arrows move, Enter picks, or press the key')],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('matrix_menu','matrix','acid',sp_grid,[(22,4,8,'arrows move, Enter picks, or press the key')],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('fast_menu','fast','ember',sp_bolt,[(22,4,8,'arrows move, Enter picks, or press the key')],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('shop_screen','shop','ember',sp_endmill,[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('mill_screen','mill','ice',sp_endmill,[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def wrap_gear(f):
    return lambda cv,x,hy,th: f(cv,x+8,hy+9,7,th)

def login_grid():
    key,title,theme,sp,texts,h=[x for x in SCREENS if x[0]=='login'][0]
    cv,th,_=screen(key,title,theme,sp,texts,2*5,False);return cv.final()
def build():
    os.makedirs(OUT,exist_ok=True);manifest=[]
    for i,(key,title,theme,sp,texts,h) in enumerate(SCREENS):
        if sp is sp_gear: sp=lambda cv,x,hy,th: sp_gear2(cv,x+8,hy+8,7,THEMES['ember'],teeth=8)
        cv,th,_=screen(key,title,theme,sp,texts,i*5,texts[0][0]==22)
        g=cv.final()
        # macros + fields drawn last, in original order, so cursor ends where the original left it
        tail='\x1b[6;%dH\x1b[0;1;37m%%BN  \x1b[0;1;30mn\x1b[0;1;33mod\x1b[0;1;30me \x1b[0;1;37m%%NN\x1b[0m'%(51)
        for (r,c,fg,t) in texts:
            tail+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',V2A[fg&7],t)
        name='%02d_%s.ans'%(i+3,key);open(os.path.join(OUT,name),'wb').write(emit(g,True,tail));manifest.append((name,h,title))
    cv,th=big_screen(24,False)
    for x in range(W): pass
    cv.clear(12,13,14,65)
    cv.put(12,25,'Axis Micro BBS Firmware',15);cv.put(12,24,'▐',8);cv.put(12,48,'▌',8)
    cv.put(13,22,'▐ U N D E R G R O U N D   C N C ▌',0,6);cv.put(13,22,'▐',6);cv.put(13,54,'▌',6)
    cv.put(23,0,' '*80,7);cv.put(23,2,'░▒▓',1);cv.put(23,64,'▓▒░',1)
    open(os.path.join(OUT,'01_splash_fullscreen.ans'),'wb').write(emit(cv.final(),True,'\x1b[24;1H'))
    manifest.insert(0,('01_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f','splash'))
    cv,th=big_screen(12,True)
    cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',0,6);cv.put(11,22,'▐',6);cv.put(11,57,'▌',6)
    open(os.path.join(OUT,'02_logo_banner_inline.ans'),'wb').write(emit(cv.final(),False))
    manifest.insert(1,('02_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34','logo'))
    return manifest
if __name__=='__main__':
    for m in build(): print(*m)
