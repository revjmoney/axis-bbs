#!/usr/bin/env python3
"""Axis Micro BBS - AMBER WASTELAND SALVAGE alternative set.
Palette: black, brown, yellow(amber), charcoal, grey, bone (VGA 0,6,14,8,7,15)."""
import math,os,random,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
from build_crt import bezel_window
_p=B.Canvas.p
B.Canvas.p=lambda s,hy,x,c:_p(s,int(hy),int(x),c)
W=80;OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')
TH=dict(r=[15,7,14,6,14,6,8,0],acc=14,warm=14,t1=6,t2=6)
ALLOWED={0,6,14,8,7,15}
def dust(seed):
    def f(x,y):
        h=(x*73856093^y*19349663^seed*83492791)&1023
        if 7<=y<=9 and (x+y+seed)%5<2: return ('░',6,0)                 # dusty amber sky band
        if h<5: return ('·',6,0)
        if h<9: return ('∙',8,0)
        return (' ',7,0)
    return f
class L:
    def __init__(s): s.P={}
    def p(s,y,x,c): s.P[(int(y),int(x))]=c
    def draw(s,cv,shadow=8,off=(1,2)):
        for (y,x) in s.P: cv.p(y+off[0],x+off[1],shadow)
        for (y,x) in s.P:
            for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
                if (y+oy,x+ox) not in s.P: cv.p(y+oy,x+ox,0)
        for (y,x),c in s.P.items(): cv.p(y,x,c)
def ruins(cv,hy,seed,x0=0,x1=80):
    r=random.Random(seed);x=x0
    while x<x1:
        w=r.randint(3,8);h=r.randint(2,9)
        for xx in range(x,min(x1,x+w)):
            top=hy-h+(1 if (xx-x)%3==0 and r.random()<0.4 else 0)
            for y in range(top,hy+1):
                if 0<=y<48 and cv.px[y][xx] is None: cv.p(y,xx,8 if y>top else 6)
        x+=w+r.randint(0,3)
def plate(S,x0,y0,w,h,seed,stripes=False,rivets=True):
    r=random.Random(seed)
    for y in range(y0,y0+h):
        for x in range(x0,x0+w):
            ex,ey=x-x0,y-y0
            c=7
            if ey==0 or ex==0: c=15
            elif ey==h-1 or ex==w-1: c=8
            elif (ex+ey*2+seed)%9==0: c=8            # weathering scratches
            if stripes and 1<ey<h-2 and 1<ex<w-2: c=14 if ((ex+ey)//3)%2==0 else 0
            if r.random()<0.05 and c==7: c=6         # rust / chipped paint
            if rivets and (ex in (2,w-3)) and (ey in (2,h-3)): c=0
            S.p(y,x,c)
def wheel(S,cx,cy,r):
    for y in range(int(cy-r),int(cy+r)+1):
        for x in range(int(cx-r),int(cx+r)+1):
            d=math.hypot(x-cx,y-cy)
            if d<=r: S.p(y,x,8 if d>r*0.7 else 7 if d>r*0.35 else 15 if d>r*0.15 else 0)
def crawler(cv,x0,by,w,seed,crane=True,crane_top=16):
    """Tracked salvage crawler: tread loop, road wheels, layered hull plates, cab window void, crane."""
    S=L();th=8
    # tracks
    for y in range(by-th,by+1):
        for x in range(x0,x0+w):
            ex=x-x0;ey=y-(by-th)
            edge=ey in (0,th) or ex<2 or ex>w-3
            if ex<3 and (ey==0 or ey==th) : continue
            S.p(y,x,(7 if (ex+ey)%3 else 8) if edge else 0)
    for k in range(5): wheel(S,x0+4+k*(w-8)/4,by-th/2,3)
    # hull layers
    plate(S,x0+2,by-th-8,w-4,8,seed)
    plate(S,x0+6,by-th-12,w-20,5,seed+1,stripes=True)
    # cab
    cx=x0+w-16
    plate(S,cx,by-th-18,12,10,seed+2)
    for y in range(by-th-16,by-th-12):
        for x in range(cx+2,cx+10): S.p(y,x,0 if (x+y)%5 else 6)   # black window with dim amber glow
    S.p(by-th-14,cx+8,14)
    # exhaust
    for y in range(by-th-20,by-th-12): S.p(y,x0+8,8);S.p(y,x0+9,7)
    S.draw(cv)
    if crane:
        bx,byy=x0+14,by-th-12;tx,ty=x0+w*0.3,max(crane_top,by-th-34)
        for t in range(40):
            u=t/39;x=bx+(tx-bx)*u;y=byy+(ty-byy)*u
            cv.p(int(y),int(x),14 if t%4 else 0);cv.p(int(y)+1,int(x),6)
        for y in range(int(ty),int(ty)+16): cv.p(y,int(tx)-1,7)
        cv.p(int(ty)+16,int(tx)-1,15);cv.p(int(ty)+17,int(tx)-2,8);cv.p(int(ty)+17,int(tx),8)
    for k in range(6): cv.p(by-th-21-k*2,x0+8+k%2,8 if k%2 else 6)   # smoke
def reactor(cv,cx,by,w,h,seed):
    S=L()
    for y in range(by-h,by):
        for x in range(cx-w//2,cx+w//2):
            u=(x-(cx-w//2))/w;c=[8,7,15,15,7,7,8,0][min(7,int(u*8))]
            if (y-(by-h))%4==0: c=8 if c!=15 else 7          # ribs
            if abs(x-cx)<w*0.18 and by-h*0.75<y<by-h*0.3: c=14 if (y%2==0) else 6   # core window
            S.p(y,x,c)
    for x in range(cx-w//2-2,cx+w//2+2): S.p(by-h-1,x,15 if x<cx else 7);S.p(by,x,8);S.p(by+1,x,8)
    S.draw(cv)
    for k in range(3):   # cables
        for t in range(14):
            cv.p(by-h*0.5+t*0.8+k*3,cx+w//2+2+t,8);cv.p(by-h*0.5+t*0.8+k*3+1,cx+w//2+2+t,0)
def gear(cv,cx,cy,R,teeth=10):
    S=L()
    for y in range(int(cy-R*1.3),int(cy+R*1.3)+1):
        for x in range(int(cx-R*1.3),int(cx+R*1.3)+1):
            dx=x-cx;dy=y-cy;d=math.hypot(dx,dy);a=math.atan2(dy,dx)
            if not(d<R or (math.cos(a*teeth)>0.2 and d<R*1.25)): continue
            if d<R*0.25: c=0
            elif d<R*0.4: c=14
            elif d<R*0.75: c=6 if (int(math.degrees(a)+360)//30)%2 else 8
            else: c=15 if -(dx+dy)/(d+.1)>0.5 else 7 if -(dx+dy)/(d+.1)>-0.3 else 8
            S.p(y,x,c)
    S.draw(cv)
def pdoor(cv,x0,y0,w,h,seed):
    S=L();plate(S,x0,y0,w,h,seed)
    plate(S,x0+3,y0+3,w-6,h-6,seed+3,rivets=False)
    for y in range(y0+h-6,y0+h-3):
        for x in range(x0+3,x0+w-3): S.p(y,x,14 if ((x+y)//2)%2 else 0)
    cx,cy=x0+w//2,y0+h//2-2
    for a in range(0,360,6): S.p(cy+math.sin(math.radians(a))*4,cx+math.cos(math.radians(a))*4,15)
    for k in range(4):
        for t in range(5): S.p(cy+math.sin(k*math.pi/2+0.4)*t,cx+math.cos(k*math.pi/2+0.4)*t,7)
    S.p(cy,cx,14)
    S.draw(cv)
def antenna(cv,cx,by,h):
    S=L()
    for y in range(by-h,by+1):
        hw=(y-(by-h))*0.25
        S.p(y,cx-hw,7);S.p(y,cx+hw,8)
        if (y-by)%4==0:
            for x in range(int(cx-hw),int(cx+hw)+1): S.p(y,x,7)
    S.draw(cv)
    for y in range(by-h-2,by-h+1): cv.p(y,cx,15)
    cv.p(by-h-3,cx,14)
    for r in (5,9,13):
        for a in range(-60,61,6):
            for sgn in (-1,1):
                x=cx+sgn*math.cos(math.radians(a))*r;y=by-h-3+math.sin(math.radians(a))*r*0.8
                if 0<=int(y)<48 and 0<=int(x)<80 and cv.px[int(y)][int(x)] is None: cv.p(int(y),int(x),14 if r==5 else 6)
def containers(cv,seed):
    S=L()
    for i,(x,y,w,h,st) in enumerate(((47,30,16,12,False),(63,30,15,12,True),(53,19,18,11,False))):
        plate(S,x,y,w,h,seed+i,stripes=st)
        for xx in range(x+3,x+w-3,3):
            for yy in range(y+2,y+h-2): S.P[(yy,xx)]=8 if not st else S.P[(yy,xx)]
    S.draw(cv)
def stripes_bar(cv,hy,x0,x1):
    for x in range(x0,x1):
        for k in range(2): cv.p(hy+k,x,14 if ((x+k)//2)%2 else 0)
def header(cv,title,seed):
    B.logo(cv,title.upper(),3,0,TH,slant=False)
    for x in range(W): cv.put(5,x,' ',7)
    cv.put(5,1,'▄▀▄ ',6);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',6)
    for x in range(W): cv.put(6,x,'▀',14 if (x//2)%2 else 8,0)   # hazard stripe
P22='arrows move, Enter picks, or press the key'
def base(cv,seed): ruins(cv,44,seed,2,79)
def c_crawler(cv,seed): base(cv,seed);crawler(cv,46,44,32,seed,crane=True,crane_top=16)
def c_reactor(cv,seed): base(cv,seed);reactor(cv,61,44,22,26,seed)
def c_gear(cv,seed): base(cv,seed);gear(cv,64,29,9,12);gear(cv,51,38,5,8)
def c_crane(cv,seed):
    base(cv,seed)
    for t in range(34): cv.p(16+t//6,46+t,14 if t%4 else 0);cv.p(17+t//6,46+t,6)
    for y in range(22,32): cv.p(y,74,7)
    S=L();plate(S,64,32,15,10,seed,stripes=True);S.draw(cv)
def c_door(cv,seed): base(cv,seed);pdoor(cv,52,15,22,29,seed)
def c_antenna(cv,seed): base(cv,seed);antenna(cv,63,44,24)
def c_containers(cv,seed): base(cv,seed);containers(cv,seed)
def c_gears(cv,seed): base(cv,seed);gear(cv,55,23,6,9);gear(cv,70,28,7,10);gear(cv,58,38,5,8)
def c_fast(cv,seed):
    base(cv,seed)
    for k in range(6):
        for x in range(46,58): cv.p(26+k*3,x-k,6 if x%3 else 8)
    crawler(cv,52,44,26,seed,crane=False)
def c_reactor2(cv,seed): base(cv,seed);reactor(cv,58,44,18,24,seed);gear(cv,74,22,4,8)
def c_engine(cv,seed):
    base(cv,seed);S=L()
    for k in range(5): plate(S,47+k*6,22+(k%2)*2,6,20,seed+k,rivets=False)
    S.draw(cv);stripes_bar(cv,43,46,78);gear(cv,70,20,5,8)
SCREENS=[
 ('03_wasteland_axis_welcome','axis',c_crawler,[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_wasteland_axis_main_menu','axis',c_reactor,[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_wasteland_login','login',c_gear,[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_wasteland_apply_new_user','apply',c_crane,[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_wasteland_doors_menu','doors',c_door,[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_wasteland_messages_menu','msgs',c_antenna,[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_wasteland_files_menu','files',c_containers,[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_wasteland_matrix_menu','matrix',c_gears,[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_wasteland_fast_menu','fast',c_fast,[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_wasteland_shop_screen','shop',c_reactor2,[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_wasteland_mill_screen','mill',c_engine,[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;33mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for (r,c,fg,s) in texts: t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',B.V2A[fg&7],s)
    return t
def check(g):
    for row in g:
        for ch,fg,bg in row: assert fg in ALLOWED and bg in {0,6,7}, (ch,fg,bg)
def screen(i,title,comp,texts,menu):
    seed=i*19+5;cv=B.Canvas(24,dust(seed))
    header(cv,title,seed);comp(cv,seed)
    if menu: bezel_window(cv,8,20,3,43);cv.clear(21,21,3,45)
    else:
        rows=[r for r,*_ in texts];w=max(len(t) for *_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        bezel_window(cv,min(rows)-1,max(rows)-1,3,3+w)
    for x in range(W): cv.put(23,x,' ',7)
    cv.put(23,1,'░▒▓',6);cv.put(23,22,'A X I S   M I C R O   B B S',7);cv.put(23,52,'u.g. cnc',8);cv.put(23,76,'▓▒░',6)
    return cv
def build():
    os.makedirs(OUT,exist_ok=True);man=[]
    cv=B.Canvas(24,lambda x,y:(' ',7,0) if y<5 else dust(3)(x,y))
    ruins(cv,40,8);crawler(cv,8,42,64,7,crane=True,crane_top=10)
    for x in range(0,80,7): cv.p(43,x,8);cv.p(43,x+1,6)        # scrap on the ground
    B.logo(cv,'AXIS',5,0,TH,sx=3,sy=1)
    cv.clear(22,23,0,79)
    cv.put(22,28,'Axis Micro BBS Firmware',15);cv.put(23,23,'▐ U N D E R G R O U N D   C N C ▌',0,6);cv.put(23,23,'▐',14);cv.put(23,55,'▌',14)
    g=cv.final();check(g)
    open(os.path.join(OUT,'01_wasteland_splash_fullscreen.ans'),'wb').write(B.emit(g,True,'\x1b[24;1H'))
    man.append(('01_wasteland_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'))
    cv=B.Canvas(12,lambda x,y:(' ',7,0))
    gear(cv,7,10,5,8);gear(cv,72,10,5,8)
    B.logo(cv,'AXIS',16,2,TH,sx=2,sy=2)
    cv.clear(11,11,0,79);cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',0,6);cv.put(11,22,'▐',14);cv.put(11,57,'▌',14)
    g=cv.final();check(g)
    open(os.path.join(OUT,'02_wasteland_logo_banner_inline.ans'),'wb').write(B.emit(g,False))
    man.append(('02_wasteland_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'))
    for i,(name,title,comp,texts,h) in enumerate(SCREENS):
        cv=screen(i,title,comp,texts,texts[0][0]==22);g=cv.final();check(g)
        open(os.path.join(OUT,name+'.ans'),'wb').write(B.emit(g,True,tail(texts)));man.append((name+'.ans',h))
    return man
if __name__=='__main__':
    for m in build(): print(*m)
