#!/usr/bin/env python3
"""Axis Micro BBS - HAUNTED CRT alternative set. Palette: black, dark green, bright green, charcoal,
grey, off-white (VGA 0,2,10,8,7,15). Lead visual: large rounded CRT monitors (bevelled plastic bezel,
curved glass, stepped phosphor halo, scanlines, glass glare, burn-in) with a phantom face carved from
BLACK negative space. Supporting: cables, broken circuit traces, shadow layers."""
import math,os,random,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
W=80;OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')
TH=dict(r=[15,7,10,2,10,2,8,0],acc=10,warm=15,t1=2,t2=2)
ALLOWED={0,2,7,8,10,15}
def static(seed):
    def f(x,y):
        h=(x*73856093^y*19349663^seed*83492791)&1023
        if h<6: return ('·',10,0)
        if h<14: return ('░',8,0)
        if y%2==0 and h<40: return ('▀',8,0) if h%2 else (' ',7,0)
        return (' ',7,0)
    return f
def rrect(dx,dy,w,h,r):
    """inside test for rounded rect with origin top-left"""
    if dx<0 or dy<0 or dx>=w or dy>=h: return False
    cx=min(max(dx,r),w-1-r);cy=min(max(dy,r),h-1-r)
    return (dx-cx)**2+(dy-cy)**2<=r*r
def crt(cv,x0,hy0,w,h,seed=0,face='calm',roll=None,stand=True):
    """Large rounded CRT. w,h in square px (cols, half-rows)."""
    rnd=random.Random(seed);P={}
    for y in range(h):
        for x in range(w):
            if not rrect(x,y,w,h,max(4,h//6)): continue
            # bevelled plastic: lit top-left, dark bottom-right, mid grey body
            e=min(x,y,w-1-x,h-1-y)
            if e==0: c=15 if (x<w*0.6 and y<h*0.5) else 8
            elif e==1: c=7 if y<h*0.5 else 8
            else: c=7 if (x+y)%11 else 15
            if y>h-4 and e>=1: c=8                                     # chin shadow
            P[(y,x)]=c
    if stand:
        for y in range(h,h+4):
            ww=w//3-(y-h)*0+((y-h)*2)
            for x in range(w//2-ww//2,w//2+ww//2): P[(y,x)]=[8,7,8,7][y-h] if x>w//2-ww//2 else 15
    # glass
    gx,gy,gw,gh=4,3,w-8,h-9
    cxg,cyg=gx+gw/2,gy+gh/2
    for y in range(gh):
        for x in range(gw):
            if not rrect(x,y,gw,gh,max(3,gh//5)): continue
            dx=(x-gw/2)/(gw/2);dy=(y-gh/2)/(gh/2);d=math.hypot(dx,dy)
            v=1.15-d                                                   # stepped phosphor halo
            c=10 if v>0.55 else 2 if v>0.15 else 8 if v>-0.1 else 0
            # phantom face from negative space (only black)
            fx=dx/0.62;fy=dy/0.85
            inface=fx*fx+fy*fy<1
            if inface and c in (2,8): c=10 if fx*fx+fy*fy<0.7 else 2       # face mass glows
            ey=-0.18; ex=0.34
            eyes=((abs(fx)-ex)/0.20)**2+((fy-ey)/(0.16 if face!='sad' else 0.12))**2<1
            mo={'calm':((fx)/0.18)**2+((fy-0.48)/0.10)**2<1,'scream':((fx)/0.22)**2+((fy-0.45)/0.25)**2<1,
                'grin':abs(fy-0.45-0.25*fx*fx)<0.07 and abs(fx)<0.55,'sad':abs(fy-0.55+0.2*fx*fx)<0.07 and abs(fx)<0.4}[face]
            nose=abs(fx)<0.05+0.1*(fy-0.05) and 0.05<fy<0.25 and abs(fx)>0.02
            brow=abs(fy-ey+0.22-0.15*abs(fx))<0.05 and 0.12<abs(fx)<0.6
            if inface and (eyes or mo or nose): c=0
            elif inface and brow: c=2
            if y%2==1: c={10:2,2:0,15:7,7:8}.get(c,c)                 # scanlines
            if roll is not None and abs(y-roll)<2: c=15 if y==roll else 10  # rolling vertical-hold band
            if x+y<gw*0.28 and x+y>gw*0.18 and y<gh*0.4: c=15 if y%2==0 else 7   # glass glare streak
            P[(gy+y,gx+x)]=c
    # burn-in ghost text in corner
    for i in range(min(10,gw-8)):
        if i%3!=2: P[(gy+gh-3,gx+3+i)]=2 if P.get((gy+gh-3,gx+3+i))==0 else P.get((gy+gh-3,gx+3+i),2)
    # power LED + knobs
    P[(h-3,w-5)]=10;P[(h-3,w-8)]=15;P[(h-3,w-9)]=8
    # layers: cast shadow, outline, face
    for (y,x) in P: cv.p(hy0+y+2,x0+x+2,8)
    for (y,x) in P:
        for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
            if (y+oy,x+ox) not in P: cv.p(hy0+y+oy,x0+x+ox,0)
    for (y,x),c in P.items(): cv.p(hy0+y,x0+x,c)
def cable(cv,pts,lit=True):
    for (x0,y0),(x1,y1) in zip(pts,pts[1:]):
        n=max(abs(x1-x0),abs(y1-y0),1)
        for i in range(n+1):
            x=round(x0+(x1-x0)*i/n);y=round(y0+(y1-y0)*i/n)
            cv.p(y,x,7);cv.p(y+1,x,8)
    if lit: cv.p(pts[-1][1],pts[-1][0],15)
def circuit(cv,x0,x1,y0,y1,seed):
    rnd=random.Random(seed)
    for k in range((x1-x0)*(y1-y0)//70):
        x=rnd.randrange(x0,x1);y=rnd.randrange(y0,y1);L=rnd.randrange(5,16);hor=rnd.random()<0.65
        brk=rnd.randrange(2,L)
        for t in range(L):
            if abs(t-brk)<=1: continue                                      # broken trace gap
            xx,yy=(x+t,y) if hor else (x,y+t)
            if x0<=xx<x1 and y0<=yy<y1 and cv.px[yy][xx] is None: cv.p(yy,xx,2)
        sx,sy=(x+brk,y) if hor else (x,y+brk)
        if rnd.random()<0.5 and x0<=sx<x1 and y0<=sy<y1: cv.p(sy,sx,10)   # spark at the break
def bezel_window(cv,y0,y1,x0,x1):
    """Menu/text void framed as a dark monitor opening (frame drawn OUTSIDE the void)."""
    cv.clear(y0,y1,x0,x1)
    for x in range(x0-1,x1+2): cv.put(y0-1,x,'▄',7 if x<(x0+x1)//2 else 8);cv.put(y1+1,x,'▀',8)
    for y in range(y0,y1+1): cv.put(y,x0-1,'▐',7);cv.put(y,x1+1,'▌',8)
    cv.put(y0-1,x0-1,'▄',15)
def header(cv,title,seed):
    end=B.logo(cv,title.upper(),3,0,TH,slant=False)
    for x in range(W): cv.put(5,x,' ',7)
    cv.put(5,1,'▄▀▄ ',2);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',2)
    for x in range(W): cv.put(6,x,'▀' if x%2 else '▄',[8,2,8,10,8,2][(x+seed)%6],0)
    return end
P22='arrows move, Enter picks, or press the key'
def comp_big(face,roll=None,cx=46,w=32,h=30,hy=15):
    def f(cv,seed):
        circuit(cv,2,78,15,44,seed);cable(cv,[(cx+w//2,hy+h+3),(cx+w//2-6,44),(10,44)])
        crt(cv,cx,hy,w,h,seed,face,roll)
    return f
def comp_stack(cv,seed):
    circuit(cv,46,78,15,44,seed)
    for i,(x,y,f) in enumerate(((46,15,'grin'),(62,19,'scream'))):
        crt(cv,x,y,16,22,seed+i,f,stand=True)
def comp_menu(face,roll=None):
    def f(cv,seed):
        circuit(cv,46,78,15,44,seed);cable(cv,[(62,44),(56,40),(47,43)])
        crt(cv,48,16,30,26,seed,face,roll)
    return f
def comp_door(cv,seed):
    circuit(cv,46,78,15,44,seed)
    crt(cv,48,16,30,26,seed,'calm')
    for hy in range(20,38):   # doorway cut into the glass: negative-space portal
        for x in range(59,67): cv.p(hy,x,0 if x>59 else 2)
    cv.p(29,65,10)
SCREENS=[
 ('03_crt_axis_welcome','axis',comp_big('grin'),[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_crt_axis_main_menu','axis',comp_menu('calm'),[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_crt_login','login',comp_big('calm',cx=44,w=34),[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_crt_apply_new_user','apply',comp_big('sad'),[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_crt_doors_menu','doors',comp_door,[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_crt_messages_menu','msgs',comp_menu('scream'),[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_crt_files_menu','files',comp_menu('sad',roll=8),[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_crt_matrix_menu','matrix',comp_stack,[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_crt_fast_menu','fast',comp_menu('grin',roll=12),[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_crt_shop_screen','shop',comp_big('grin',roll=6,cx=45),[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_crt_mill_screen','mill',comp_big('scream',cx=46),[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;32mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for (r,c,fg,s) in texts: t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',B.V2A[fg&7],s)
    return t
def check(g):
    for row in g:
        for ch,fg,bg in row: assert fg in ALLOWED and bg in {0,2,7}, (ch,fg,bg)
def screen(i,title,comp,texts,menu):
    seed=i*11+1;cv=B.Canvas(24,static(seed))
    header(cv,title,seed);comp(cv,seed)
    if menu: bezel_window(cv,8,20,3,43);cv.clear(21,21,3,45)
    else:
        rows=[r for r,*_ in texts];w=max(len(t) for *_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        bezel_window(cv,min(rows)-1,max(rows)-1,3,3+w)
    for x in range(W): cv.put(23,x,' ',7)
    cv.put(23,1,'░▒▓',2);cv.put(23,22,'A X I S   M I C R O   B B S',7);cv.put(23,52,'u.g. cnc',8);cv.put(23,76,'▓▒░',2)
    return cv
def build():
    os.makedirs(OUT,exist_ok=True);man=[]
    cv=B.Canvas(24,lambda x,y:(' ',7,0) if y<5 else static(3)(x,y))
    circuit(cv,0,80,13,46,5)
    cable(cv,[(40,42),(30,45),(2,45)]);cable(cv,[(44,42),(60,46),(78,44)])
    crt(cv,13,11,54,32,7,'scream',roll=None)
    B.logo(cv,'AXIS',5,0,TH,sx=3,sy=1)
    cv.clear(22,23,0,79)
    cv.put(22,28,'Axis Micro BBS Firmware',15);cv.put(23,23,'▐ U N D E R G R O U N D   C N C ▌',0,2);cv.put(23,23,'▐',10);cv.put(23,55,'▌',10)
    g=cv.final();check(g)
    open(os.path.join(OUT,'01_crt_splash_fullscreen.ans'),'wb').write(B.emit(g,True,'\x1b[24;1H'))
    man.append(('01_crt_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'))
    cv=B.Canvas(12,static(9))
    circuit(cv,0,80,0,22,2)
    crt(cv,1,1,14,18,2,'grin',stand=False);crt(cv,65,1,14,18,4,'scream',stand=False)
    B.logo(cv,'AXIS',15,2,TH,sx=2,sy=2)
    cv.clear(11,11,0,79);cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',0,2);cv.put(11,22,'▐',10);cv.put(11,57,'▌',10)
    g=cv.final();check(g)
    open(os.path.join(OUT,'02_crt_logo_banner_inline.ans'),'wb').write(B.emit(g,False))
    man.append(('02_crt_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'))
    for i,(name,title,comp,texts,h) in enumerate(SCREENS):
        cv=screen(i,title,comp,texts,texts[0][0]==22);g=cv.final();check(g)
        open(os.path.join(OUT,name+'.ans'),'wb').write(B.emit(g,True,tail(texts)));man.append((name+'.ans',h))
    return man
if __name__=='__main__':
    for m in build(): print(*m)
