# Axis Micro BBS: AMBER WASTELAND SALVAGE alternative set (2026-11-07)

Theme 4 of 4. Original underground-style art; no group or artist affiliation. Earlier packs are untouched.

- Palette: black, brown, amber/yellow, charcoal, grey and bone only (VGA 0/6/14/8/7/15). Validated per cell.
- Hero: a tracked salvage crawler with a tread loop, shaded road wheels, layered riveted hull plates with bevels, scratches and chipped rust paint, a hazard-striped deck plate, a cab with a black window void and dim amber glow, an exhaust with smoke, and a crane boom with hook.
- Environment: amber dust band, ruined-city horizon silhouettes with rust-lit tops, scrap and dust specks, hazard-stripe header rule. Sprites use layers: charcoal cast shadow, then black outline, then the face.
- Per screen: splash = giant crawler; welcome = crawler with crane; main menu = ribbed reactor with amber core and cables; login = exposed gears; apply = crane hoisting a striped container; doors = rusted pressure door with wheel and hazard sill; msgs = lattice radio mast with amber signal arcs; files = salvage container stack; matrix = gear cluster; fast = small crawler with dust streaks; shop = reactor + gear; mill = ribbed engine block on a hazard bar.
- Semantics are the same as the other sets: 80 columns, CP437, `ESC[2J ESC[H` plus per-row `ESC[r;1H` (row 24 stops at column 79); 02 is 12 inline rows. `%BN  node %NN` is at row 6, column 51. Source placements (12;4, 14;4, 22;4) are written last, in order; end cursors match the originals.
- Menu window (assumption; firmware not inspected): rows 9-21, columns 4-44 are black and validated blank. Wider menus would overlap the art.
- Local emulator only; not tested on a live BBS. Preview text glyphs use the Terminus font.

## Mapping (file <- uploaded source sha256 filename)
- `01_wasteland_splash_fullscreen.ans` <- `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f`
- `02_wasteland_logo_banner_inline.ans` <- `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34`
- `03_wasteland_axis_welcome.ans` <- `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4`
- `04_wasteland_axis_main_menu.ans` <- `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78`
- `05_wasteland_login.ans` <- `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f`
- `06_wasteland_apply_new_user.ans` <- `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e`
- `07_wasteland_doors_menu.ans` <- `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc`
- `08_wasteland_messages_menu.ans` <- `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d`
- `09_wasteland_files_menu.ans` <- `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678`
- `10_wasteland_matrix_menu.ans` <- `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84`
- `11_wasteland_fast_menu.ans` <- `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264`
- `12_wasteland_shop_screen.ans` <- `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1`
- `13_wasteland_mill_screen.ans` <- `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855`

Rebuild: `python3 src/build_wasteland.py && python3 src/validate_wasteland.py > validation.json && python3 src/sheet.py` (deterministic; Pillow).
