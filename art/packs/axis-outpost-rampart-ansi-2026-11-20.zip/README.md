# OUTPOST

Original AXIS look pack. The art was drawn for this board.
Dialect: renegade

ans/ holds the numbered screens the installer renames.
axis/ holds the firmware names, the lite screens, the list templates and THEME.CFG.
A .LITE.ANS screen is for a slow radio caller and stays under 700 bytes.

File sizes

- ans/01_outpost_prelogon.ans  1686 B
- ans/02_outpost_banner.ans  214 B
- ans/03_outpost_bulletin.ans  1691 B
- ans/04_outpost_main.ans  1687 B
- ans/05_outpost_login.ans  1751 B
- ans/06_outpost_newuser.ans  1711 B
- ans/07_outpost_doors.ans  1682 B
- ans/08_outpost_messages.ans  1677 B
- ans/09_outpost_files.ans  1671 B
- ans/10_outpost_matrix.ans  1680 B
- ans/11_outpost_fast.ans  1681 B
- ans/12_outpost_shop.ans  1698 B
- ans/13_outpost_mill.ans  1682 B
- axis/BULLETIN.ANS  1691 B
- axis/BULLETIN.LITE.ANS  276 B
- axis/DOORS.ANS  1682 B
- axis/DOORS.LITE.ANS  298 B
- axis/FASTLOGN.ANS  1681 B
- axis/FASTLOGN.LITE.ANS  303 B
- axis/FILES.ANS  1671 B
- axis/FILES.LITE.ANS  298 B
- axis/FILES.LST  188 B
- axis/GOODBYE.ANS  632 B
- axis/GOODBYE.LITE.ANS  335 B
- axis/LOGIN.ANS  1751 B
- axis/LOGIN.LITE.ANS  340 B
- axis/MAIN.ANS  1687 B
- axis/MAIN.LITE.ANS  302 B
- axis/MATRIX.ANS  1680 B
- axis/MATRIX.LITE.ANS  299 B
- axis/MILL.ANS  1682 B
- axis/MILL.LITE.ANS  274 B
- axis/MSGS.ANS  1677 B
- axis/MSGS.LITE.ANS  301 B
- axis/MSGS.LST  204 B
- axis/NEWUSER.ANS  1711 B
- axis/NEWUSER.LITE.ANS  286 B
- axis/PRELOGON.ANS  1686 B
- axis/PRELOGON.LITE.ANS  270 B
- axis/SHOP.ANS  1698 B
- axis/SHOP.LITE.ANS  287 B
- axis/THEME.CFG  118 B
- axis/USERS.LST  194 B
