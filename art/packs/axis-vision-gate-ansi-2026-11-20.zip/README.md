# VISION GATE

Original AXIS look pack. The art was drawn for this board.
Dialect: vision3

ans/ holds the numbered screens the installer renames.
axis/ holds the firmware names, the lite screens, the list templates and THEME.CFG.
A .LITE.ANS screen is for a slow radio caller and stays under 700 bytes.

File sizes

- ans/01_vision_prelogon.ans  1623 B
- ans/02_vision_banner.ans  187 B
- ans/03_vision_bulletin.ans  1628 B
- ans/04_vision_main.ans  1620 B
- ans/05_vision_login.ans  1690 B
- ans/06_vision_newuser.ans  1648 B
- ans/07_vision_doors.ans  1618 B
- ans/08_vision_messages.ans  1613 B
- ans/09_vision_files.ans  1607 B
- ans/10_vision_matrix.ans  1616 B
- ans/11_vision_fast.ans  1617 B
- ans/12_vision_shop.ans  1635 B
- ans/13_vision_mill.ans  1619 B
- axis/BULLETIN.ANS  1628 B
- axis/BULLETIN.LITE.ANS  259 B
- axis/DOORS.ANS  1618 B
- axis/DOORS.LITE.ANS  281 B
- axis/FASTLOGN.ANS  1617 B
- axis/FASTLOGN.LITE.ANS  286 B
- axis/FILES.ANS  1607 B
- axis/FILES.LITE.ANS  281 B
- axis/FILES.LST  190 B
- axis/GOODBYE.ANS  604 B
- axis/GOODBYE.LITE.ANS  316 B
- axis/LOGIN.ANS  1690 B
- axis/LOGIN.LITE.ANS  326 B
- axis/MAIN.ANS  1620 B
- axis/MAIN.LITE.ANS  285 B
- axis/MATRIX.ANS  1616 B
- axis/MATRIX.LITE.ANS  282 B
- axis/MILL.ANS  1619 B
- axis/MILL.LITE.ANS  257 B
- axis/MSGS.ANS  1613 B
- axis/MSGS.LITE.ANS  284 B
- axis/MSGS.LST  206 B
- axis/NEWUSER.ANS  1648 B
- axis/NEWUSER.LITE.ANS  269 B
- axis/PRELOGON.ANS  1623 B
- axis/PRELOGON.LITE.ANS  253 B
- axis/SHOP.ANS  1635 B
- axis/SHOP.LITE.ANS  270 B
- axis/THEME.CFG  103 B
- axis/USERS.LST  200 B
