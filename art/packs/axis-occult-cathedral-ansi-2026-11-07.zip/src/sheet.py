import sys,glob,os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));import render
from PIL import Image,ImageDraw
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..');ims=[]
for f in sorted(glob.glob(D+'/ans/*.ans')):
    g,_,_,_=render.emulate(open(f,'rb').read(),rows=25);n=os.path.basename(f)[:-4]
    ims.append((n,render.png(g,D+'/previews/final/%s.png'%n,rows=12 if 'inline' in n else 24)))
cols=3;sc=0.5;w,h=320,int(384*sc)+18
S=Image.new('RGB',(cols*(w+8),((len(ims)+2)//3)*(h+8)),(18,10,22));d=ImageDraw.Draw(S)
for i,(n,im) in enumerate(ims):
    x=(i%cols)*(w+8);y=(i//cols)*(h+8);S.paste(im.resize((w,int(im.height*sc)),Image.LANCZOS),(x,y+18));d.text((x+2,y+3),n,fill=(230,150,255))
S.save(D+'/previews/contact_sheet_cathedral_13.png')
