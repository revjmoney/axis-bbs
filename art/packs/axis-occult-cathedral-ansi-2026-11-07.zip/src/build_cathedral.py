#!/usr/bin/env python3
"""Axis Micro BBS - PURPLE OCCULT CATHEDRAL alternative set.
Palette: black, purple, magenta, charcoal, grey, bone (VGA 0,5,13,8,7,15). Gothic pointed arches,
voussoir rings, cylindrical columns, rose/lancet stained glass, black crypt voids, fictional sigils,
perspective floor lines, candles with long glow."""
import math,os,random,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
from build_crt import bezel_window
W=80;OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')
TH=dict(r=[15,7,15,7,13,5,8,0],acc=13,warm=15,t1=5,t2=5)
ALLOWED={0,5,13,8,7,15}
def gloom(seed):
    def f(x,y):
        h=(x*73856093^y*19349663^seed*83492791)&1023
        if h<4: return ('·',5,0)
        if y>=7 and (x//6+y//3)%2==0 and h<60: return ('░',8,0)   # faint ashlar masonry
        return (' ',7,0)
    return f
def pointed(dx,dy,w,h):
    """inside pointed (equilateral-ish) arch; origin bottom-center; dy negative upward; springline at -h+w*0.87"""
    ys=-h+w*0.87
    if dy>0 or abs(dx)>w/2: return False
    if dy>=ys: return True
    return math.hypot(dx-w/2,dy-ys)<=w and math.hypot(dx+w/2,dy-ys)<=w
class L:
    def __init__(s): s.P={}
    def p(s,y,x,c): s.P[(int(y),int(x))]=c
    def draw(s,cv,shadow=5):
        for (y,x) in s.P: cv.p(y+1,x+2,shadow)
        for (y,x) in s.P:
            for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
                if (y+oy,x+ox) not in s.P: cv.p(y+oy,x+ox,0)
        for (y,x),c in s.P.items(): cv.p(y,x,c)
def stone(x,y,lit):
    c=15 if lit>0.5 else 7 if lit>-0.1 else 8
    if (y%4==0) or ((x+(y//4)*3)%7==0): c=8 if c!=8 else 0       # mortar joints
    return c
def arch(cv,cx,by,w,h,ring=4,fill='void',seed=0):
    """Stone pointed arch: voussoir ring + interior (void / glass / door)."""
    S=L();iw=w-2*ring;ih=h-ring
    for y in range(int(by-h),int(by)+1):
        for x in range(int(cx-w/2),int(cx+w/2)+1):
            dx=x-cx;dy=y-by
            if not pointed(dx,dy,w,h): continue
            if pointed(dx,dy,iw,ih):
                if fill=='void': c=0
                elif fill=='glass':
                    u=(dx+iw/2)/iw;k=(int(u*4)+int((-dy)/4))%3
                    c=[5,13,15][k] if (int(dx)%max(2,iw//4)!=0 and int(-dy)%5!=0) else 8   # leaded panes
                    if abs(dx)<1 and -dy>ih*0.4: c=7                                    # mullion
                elif fill=='door':
                    c=8 if int(dx)%4 else 0
                    if int(-dy) in (h//3,2*h//3) : c=7
                else: c=0
                S.p(y,x,c)
            else:
                lit=-(dx/(w/2))*0.8+0.2
                S.p(y,x,stone(x,y,lit))
    S.draw(cv)
def column(cv,x0,y0,y1,w=5):
    ramp=[8,7,15,7,8,5,0][:w] if w<=7 else [8,7,15,15,7,8,5,0]
    for y in range(y0,y1+1):
        for i,c in enumerate(ramp): cv.p(y,x0+i,c if y%9 else 8)
    for i in range(-1,w+1): cv.p(y0-1,x0+i,15 if i<w//2 else 7);cv.p(y0-2,x0+i,7);cv.p(y1+1,x0+i,8)
def rose(cv,cx,cy,r):
    S=L()
    for y in range(int(cy-r),int(cy+r)+1):
        for x in range(int(cx-r),int(cx+r)+1):
            d=math.hypot(x-cx,y-cy)
            if d>r: continue
            a=math.atan2(y-cy,x-cx)
            if d>r*0.85: c=stone(x,y,-math.cos(a+0.8))
            elif d<r*0.15: c=15
            else:
                petal=(math.cos(a*8)+1)/2
                if abs(math.sin(a*4))<0.12 or abs(d-r*0.5)<0.7: c=8            # tracery
                else: c=13 if petal>0.6 else 5 if d>r*0.5 else 15 if petal>0.8 else 13
            S.p(y,x,c)
    S.draw(cv)
def sigil(cv,cx,cy,r,n=7,step=3):
    for a in range(0,360,2):
        cv.p(int(cy+math.sin(math.radians(a))*r),int(cx+math.cos(math.radians(a))*r),13)
    pts=[(cx+math.cos(2*math.pi*k/n-math.pi/2)*r*0.9,cy+math.sin(2*math.pi*k/n-math.pi/2)*r*0.9) for k in range(n)]
    for k in range(n):
        (x0,y0),(x1,y1)=pts[k],pts[(k+step)%n];m=int(max(abs(x1-x0),abs(y1-y0)))+1
        for t in range(m+1): cv.p(int(y0+(y1-y0)*t/m),int(x0+(x1-x0)*t/m),5 if t%3 else 13)
    cv.p(int(cy),int(cx),15)
def candle(cv,x,by,h):
    for y in range(by-h,by+1): cv.p(y,x,15 if y<by-h+2 else 7);cv.p(y,x+1,8)
    cv.p(by-h-1,x,15);cv.p(by-h-2,x,13)
    for r in (3,):
        for yy in range(by-h-5,by-h+1):
            for xx in range(x-3,x+4):
                if 0<=yy<48 and 0<=xx<80 and cv.px[yy][xx] is None and math.hypot(xx-x,yy-(by-h-2))<3: cv.p(yy,xx,5)
def floor(cv,hy0,hy1,vx):
    for hy in range(hy0,hy1):
        for x in range(80):
            if cv.px[hy][x] is not None: continue
            z=hy-hy0+1
            if abs(((x-vx)/z*3)%6)<0.5 or hy in (hy0+2,hy0+5,hy1-1): cv.p(hy,x,8 if hy<hy1-1 else 5)
def drape(cv,x0,y0,y1,w):
    for y in range(y0,y1):
        for x in range(x0,x0+w):
            c=[5,13,5,0][(x-x0+((y-y0)//6))%4]
            cv.p(y,x,c)
def header(cv,title,seed):
    B.logo(cv,title.upper(),3,0,TH,slant=False)
    for x in range(W): cv.put(5,x,' ',7)
    cv.put(5,1,'▄▀▄ ',5);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',5)
    for x in range(W): cv.put(6,x,'▀▄'[x%2],[8,5,8,13,8,5,8,7][(x+seed)%8],0)
P22='arrows move, Enter picks, or press the key'
# ------------- compositions -------------
def c_nave(cv,seed):   # welcome: columns + glass arch + candles
    floor(cv,40,46,62);column(cv,47,16,40);column(cv,73,16,40)
    arch(cv,62,40,20,26,3,'glass');candle(cv,55,44,3);candle(cv,69,44,3)
def c_lancet(cv,seed):
    column(cv,47,16,42,5);arch(cv,64,43,22,28,3,'glass');candle(cv,59,45,2);candle(cv,69,45,2)
def c_crypt(cv,seed):  # login
    floor(cv,40,46,64);arch(cv,64,42,26,26,4,'void');sigil(cv,64,24,5)
    candle(cv,50,44,4);candle(cv,77,44,4);column(cv,46,18,40,4)
def c_rose(cv,seed):   # apply
    floor(cv,40,46,62);rose(cv,62,27,12);column(cv,46,16,40,4);column(cv,75,16,40,4)
def c_door(cv,seed):
    arch(cv,62,43,24,28,4,'door');sigil(cv,62,27,4,5,2)
    for k in range(3):
        for x in range(54-k*2,71+k*2): cv.p(44+k,x,[7,8,5][k])
def c_triple(cv,seed):  # msgs: three lancets
    for k,x in enumerate((52,62,72)): arch(cv,x,42,9,22+(4 if k==1 else 0),2,'glass')
    for x in range(46,79): cv.p(43,x,7);cv.p(44,x,8)
def c_arcade(cv,seed):  # files: crypt arcade of voids
    floor(cv,40,46,62)
    for k,x in enumerate((52,62,72)): arch(cv,x,40,10,18,2,'void');candle(cv,x,40,2)
    for x in range(46,79): cv.p(19,x,7 if x%3 else 15);cv.p(20,x,8)
def c_rosegrid(cv,seed):
    for i in range(2):
        for j in range(2): rose(cv,55+j*15,22+i*14,6)
def c_candles(cv,seed):
    sigil(cv,62,26,10,7,3)
    for k in range(6): candle(cv,48+k*6,44,4+(k%3)*2)
def c_altar(cv,seed):   # shop
    drape(cv,44,14,40,5);drape(cv,74,14,40,5)
    arch(cv,61,40,22,26,3,'glass')
    for y in range(38,44):
        for x in range(47,75): cv.p(y,x,15 if y==38 else 7 if y<41 else 8)
    candle(cv,52,37,4);candle(cv,70,37,4)
def c_sigil(cv,seed):   # mill
    floor(cv,40,46,62);column(cv,45,16,40,4);column(cv,75,16,40,4);sigil(cv,62,28,12,9,4)
SCREENS=[
 ('03_cathedral_axis_welcome','axis',c_nave,[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_cathedral_axis_main_menu','axis',c_lancet,[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_cathedral_login','login',c_crypt,[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_cathedral_apply_new_user','apply',c_rose,[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_cathedral_doors_menu','doors',c_door,[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_cathedral_messages_menu','msgs',c_triple,[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_cathedral_files_menu','files',c_arcade,[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_cathedral_matrix_menu','matrix',c_rosegrid,[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_cathedral_fast_menu','fast',c_candles,[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_cathedral_shop_screen','shop',c_altar,[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_cathedral_mill_screen','mill',c_sigil,[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;35mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for (r,c,fg,s) in texts: t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',B.V2A[fg&7],s)
    return t
def check(g):
    for row in g:
        for ch,fg,bg in row: assert fg in ALLOWED and bg in {0,5,7}, (ch,fg,bg)
def screen(i,title,comp,texts,menu):
    seed=i*17+3;cv=B.Canvas(24,gloom(seed))
    header(cv,title,seed);comp(cv,seed)
    if menu: bezel_window(cv,8,20,3,43);cv.clear(21,21,3,45)
    else:
        rows=[r for r,*_ in texts];w=max(len(t) for *_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        bezel_window(cv,min(rows)-1,max(rows)-1,3,3+w)
    for x in range(W): cv.put(23,x,' ',7)
    cv.put(23,1,'░▒▓',5);cv.put(23,22,'A X I S   M I C R O   B B S',7);cv.put(23,52,'u.g. cnc',8);cv.put(23,76,'▓▒░',5)
    return cv
def build():
    os.makedirs(OUT,exist_ok=True);man=[]
    cv=B.Canvas(24,lambda x,y:(' ',7,0) if y<5 else gloom(3)(x,y))
    floor(cv,40,44,40)
    for x0 in (2,62):   # flanking towers with lancets
        for y in range(14,42):
            for x in range(x0,x0+16): cv.p(y,x,stone(x,y,0.4 if x<x0+8 else -0.3))
        arch(cv,x0+8,38,8,18,2,'glass')
        for k in range(4): cv.p(13-k,x0+8-k,7);cv.p(13-k,x0+8+k,8)   # spire tips
    for y in range(12,42):
        for x in range(18,62): cv.p(y,x,stone(x,y,0.3 if x<40 else -0.3))
    rose(cv,40,19,7)
    arch(cv,40,42,22,16,3,'void')     # black portal = negative space
    candle(cv,30,43,3);candle(cv,50,43,3)
    B.logo(cv,'AXIS',5,0,TH,sx=3,sy=1)
    cv.clear(22,23,0,79)
    cv.put(22,28,'Axis Micro BBS Firmware',15);cv.put(23,23,'▐ U N D E R G R O U N D   C N C ▌',0,5);cv.put(23,23,'▐',13);cv.put(23,55,'▌',13)
    g=cv.final();check(g)
    open(os.path.join(OUT,'01_cathedral_splash_fullscreen.ans'),'wb').write(B.emit(g,True,'\x1b[24;1H'))
    man.append(('01_cathedral_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'))
    cv=B.Canvas(12,lambda x,y:(' ',7,0))
    arch(cv,7,21,10,20,2,'glass');arch(cv,72,21,10,20,2,'glass')
    B.logo(cv,'AXIS',16,2,TH,sx=2,sy=2)
    cv.clear(11,11,0,79);cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',0,5);cv.put(11,22,'▐',13);cv.put(11,57,'▌',13)
    g=cv.final();check(g)
    open(os.path.join(OUT,'02_cathedral_logo_banner_inline.ans'),'wb').write(B.emit(g,False))
    man.append(('02_cathedral_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'))
    for i,(name,title,comp,texts,h) in enumerate(SCREENS):
        cv=screen(i,title,comp,texts,texts[0][0]==22);g=cv.final();check(g)
        open(os.path.join(OUT,name+'.ans'),'wb').write(B.emit(g,True,tail(texts)));man.append((name+'.ans',h))
    return man
if __name__=='__main__':
    for m in build(): print(*m)
