# Axis Micro BBS: PURPLE OCCULT CATHEDRAL alternative set (2026-11-07)

Theme 3 of 4. Original underground-style art with fictional occult motifs; no group or artist affiliation. Earlier packs are untouched.

- Palette: black, purple, magenta, charcoal, grey and bone only (VGA 0/5/13/8/7/15). Validated per cell.
- Architecture: pointed (equilateral) gothic arches with shaded voussoir rings and mortar joints; cylindrical shaded columns with capitals; leaded stained-glass lancets with mullions; a tracery rose window; black crypt portals as negative-space depth; perspective floor lines; candles with purple glow; drapes; fictional star sigils.
- Per screen: splash = cathedral facade (two spired towers with lancets, central rose window, black portal, candles); banner = AXIS between two lancets; welcome = nave columns + glass arch + candles; main menu = tall lancet + column; login = crypt doorway with sigil; apply = rose window between columns; doors = studded crypt door with steps; msgs = triple lancets; files = crypt arcade; matrix = 2x2 rose windows; fast = sigil + candle row; shop = altar under glass arch with drapes; mill = large sigil between columns.
- Semantics are the same as the other sets: 80 columns, CP437, `ESC[2J ESC[H` plus per-row `ESC[r;1H` (row 24 stops at column 79); 02 is 12 inline rows. `%BN  node %NN` is at row 6, column 51. Source placements (12;4, 14;4, 22;4) are written last, in order; end cursors match the originals.
- Menu window (assumption; firmware not inspected): rows 9-21, columns 4-44 are black and validated blank. Wider menus would overlap the art.
- Local emulator only; not tested on a live BBS. Preview text glyphs use the Terminus font.

## Mapping (file <- uploaded source sha256 filename)
- `01_cathedral_splash_fullscreen.ans` <- `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f`
- `02_cathedral_logo_banner_inline.ans` <- `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34`
- `03_cathedral_axis_welcome.ans` <- `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4`
- `04_cathedral_axis_main_menu.ans` <- `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78`
- `05_cathedral_login.ans` <- `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f`
- `06_cathedral_apply_new_user.ans` <- `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e`
- `07_cathedral_doors_menu.ans` <- `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc`
- `08_cathedral_messages_menu.ans` <- `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d`
- `09_cathedral_files_menu.ans` <- `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678`
- `10_cathedral_matrix_menu.ans` <- `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84`
- `11_cathedral_fast_menu.ans` <- `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264`
- `12_cathedral_shop_screen.ans` <- `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1`
- `13_cathedral_mill_screen.ans` <- `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855`

Rebuild: `python3 src/build_cathedral.py && python3 src/validate_cathedral.py > validation.json && python3 src/sheet.py` (deterministic; Pillow).
