# AXIS / RUPTURE v2 — clearer typography, approved body preserved

Targeted revision only: every top heading is redrawn with separated angular letter cores, three-column breathing gaps, a regular baseline, mild right lean, open black counters, luminous crossbars, silver/green bevels and a short rear extrusion. No crossing thorns run through the letter cores. Rear cables are excluded from the counters. No new caption was added to compensate for unreadable lettering; the small captions already present in v1 are unchanged.

The anatomical skulls, broken housings, shards, foreground cable paths, functional text and footers are the approved v1 artwork. All cells outside the exact permitted heading masks are preserved as **character + foreground + background**, not merely visually similar. All existing v1 source, ANSI, preview and ZIP files are byte-identical.

## Results
- 13 revised CP437 ANSI files in `ans/`, with the same functional filenames.
- 13 actual ANSI-emulator PNGs at normal 640-pixel terminal width in `previews/`; five 2x nearest-neighbour heroes.
- `previews/contact_sheet_hardcore_v2_13.png`: all screens.
- `previews/all_13_header_crops_before_after_v2.png`: all old/new header crops at original terminal pixel scale, labels outside the art.
- `previews/splash_before_after_v2.png`: approved artwork and clearer lettering side by side.
- `validation.json`: deterministic rebuild, full compatibility and exact body-invariance audit.
- `header_edit_regions.json`: complete 1-based allowed-cell lists for each file. Not a broad permission to redraw a whole rectangular band.
- `archive_integrity.json`: deterministic archive SHA-256 / CRC receipt, beside the working files rather than recursively inside the ZIP.

## Minimal allowed regions and invariance
The mask is the union of cells touched by the OLD heading and NEW heading, including the old extrusion, the new bevel/keyline and backing needed to clear the counters. Other cells within each bounding rectangle are still protected if they are not on this explicit list. The old functional title extrusion extended into rows 6-7: those old title fragments are included for cleanup even though the new letter cores fit rows 1-4 and the new extrusion fits rows 1-5. Splash/banner old thorn lettering extended through row 12 and column 49; no other portion of those screens is authorized to change.

| File | Heading | Allowed bounding rows / columns (1-based; exact sparse mask in JSON) | Changed cells outside mask |
|---|---|---|---|
| `01_crt_splash_fullscreen.ans` | AXIS | rows 1-12 / cols 1-49 | 0 |
| `02_crt_logo_banner_inline.ans` | AXIS | rows 1-12 / cols 1-49 | 0 |
| `03_crt_axis_welcome.ans` | AXIS | rows 1-7 / cols 3-51 | 0 |
| `04_crt_axis_main_menu.ans` | AXIS | rows 1-7 / cols 3-51 | 0 |
| `05_crt_login.ans` | LOGIN | rows 1-7 / cols 3-63 | 0 |
| `06_crt_apply_new_user.ans` | APPLY | rows 1-7 / cols 3-67 | 0 |
| `07_crt_doors_menu.ans` | DOORS | rows 1-7 / cols 3-67 | 0 |
| `08_crt_messages_menu.ans` | MSGS | rows 1-7 / cols 3-54 | 0 |
| `09_crt_files_menu.ans` | FILES | rows 1-7 / cols 3-63 | 0 |
| `10_crt_matrix_menu.ans` | MATRIX | rows 1-7 / cols 3-76 | 0 |
| `11_crt_fast_menu.ans` | FAST | rows 1-7 / cols 3-54 | 0 |
| `12_crt_shop_screen.ans` | SHOP | rows 1-7 / cols 3-54 | 0 |
| `13_crt_mill_screen.ans` | MILL | rows 1-7 / cols 3-49 | 0 |

**19,346 protected body cells checked; zero changed.** Background and overlap changes are confined to the old/new heading footprint. Foreground cables below the heading, skulls, shattered metal, menu apertures and footers outside that footprint are exact v1 cells. ANSI is reserialized with explicit blank-cell colors so even invisible foreground state is preserved; ANSI byte streams need not be identical, but the old deliverables themselves are untouched.

## Editing / rebuilding
Python 3 + Pillow + NumPy + SciPy. Preview font: existing `/usr/share/fonts/truetype/terminus/TerminusTTF-4.46.0.ttf`; this is Terminus, not an IBM VGA ROM font.
```sh
python3 src/build_v2.py
python3 src/validate_v2.py > validation.json
python3 src/render_v2.py
python3 src/package_v2.py
```
`src/build_v2.py` contains the new editable glyphs, spacing, slant and bevel treatment. `src/body_v1.py` is a copy of the approved body generator, used to recover backing under removed letters. The build protects all non-heading cells with the bundled exact baseline (`assets/v1_baseline_cells.json`). The original sources in the parent folder are not modified. `src/ansi_core.py` serializes every cell explicitly; `src/render.py` provides the local emulator.
The full old-file-preservation audit refers to the original local v1 paths recorded in `assets/preserved_v1_files.json`. These files must still be present for that part of validation; the art rebuild itself uses the bundled baseline and assets and is portable. Baseline ANSI hashes are recorded in `assets/v1_ansi_sha256.json`.

## Compatibility / host assumptions (unchanged)
- 80-column CP437; classic SGR / basic cursor addressing only. Palette VGA 0/2/10/8/7/15. No Unicode in ANSI output, truecolor, blink or iCE.
- Fullscreens are 24 rows, no last-column write on row 24, no scroll in local 24- or 25-row emulation.
- Inline banner is 12 rows, no clear/cursor commands; final cursor remains 12;76. Splash retains the explicitly normalized safe cursor 24;1 (the original uploaded splash was 30 rows).
- `%BN  node %NN` stays at 6;51; menu prompt at 22;4. Login `Handle:   |{P}` stays 12;4 and `Password: |{O}` stays 14;4; final cursor 14;18. All other functional text/cursors retain the source contract.
- Menu rows 9-21, columns 4-44 remain blank on all six menu screens. The 41-column host menu width is an assumption, not firmware-verified.
- The heading `MSGS` is the existing source abbreviation for messages, now drawn with distinct readable letter cores.
- Local emulator only: not installed or live-tested on the BBS, telnet or CYD.

The previously approved face remains derived from the owner-supplied skull reference (https://x.com/littlebitspace/status/1948723353969185137); this revision does not redraw or regenerate it. No invented artist credits or scene-group affiliation. No image-generation service, repositories, websites or live BBS writes.

## Original deliverable preserved
`axis-crt-hardcore-ansi-2026-11-07.zip` remains SHA-256 `c5fcc061844cc518bc521a2d8aeeb83d1e5939278c0fb9749e7212b6feb73024`.
New archive: `../axis-crt-hardcore-ansi-2026-11-07-v2.zip`.

## Upload mapping
Upload identifiers are filenames, not literal content SHA-256s; actual source hashes are recorded separately.

| Revised ANSI | Source upload identifier | Actual source SHA-256 |
|---|---|---|
| `01_crt_splash_fullscreen.ans` | `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f` | `387848dc4c71b72b3eb8d7189cbe8bc1ef03d2e8f62fc36b6f3a65e66f217d60` |
| `02_crt_logo_banner_inline.ans` | `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34` | `d5e15dcb3ad7246912e7a34f1497421daae599fcdaef78191b3bc33c5cf3afbd` |
| `03_crt_axis_welcome.ans` | `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4` | `905380d48ea5943100e0a3e3246148aa4205b48c98d15685598dc9e53731f289` |
| `04_crt_axis_main_menu.ans` | `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78` | `32a2a4b1053ff601e9f937233234992ab4cb4e0ad6da89c32bc19957562a16c7` |
| `05_crt_login.ans` | `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f` | `9a1459143fa9d6e5631ad11d872abb45191f2b95f3e74dbf6fa89e06f841a1ee` |
| `06_crt_apply_new_user.ans` | `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e` | `cc4cc0d7f81e2959fc8d562ff9e3cb5c38b94c974267136dc10a390637cadc21` |
| `07_crt_doors_menu.ans` | `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc` | `e7cef58f0f54d0cfe7989cc92d165e6b3f0c350165dabf64f90b43010472aea4` |
| `08_crt_messages_menu.ans` | `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d` | `9c9cbe1b3930bc54ddcce709263534f4ef9116a173f32f57f41c087404459ec1` |
| `09_crt_files_menu.ans` | `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678` | `37e76a3cbc1dc5f9b23b42c7d5b12d09fa8f3c4f7d0217634d402d3aeec7fa8d` |
| `10_crt_matrix_menu.ans` | `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84` | `4e79380607b384835eafbc10f8ff4172ff442b37d9f1d79cc278fbc9f2c180c8` |
| `11_crt_fast_menu.ans` | `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264` | `fb387e9695b3a6f0dfe143a1f5c59d26175c87a67811935cc62877bcb044b825` |
| `12_crt_shop_screen.ans` | `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1` | `70ac709c404612d8ae2f201612ce8af82306b8ba2ed508f0a9f2ad2b513e98b4` |
| `13_crt_mill_screen.ans` | `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855` | `8d7b1be9394bacff41cc4e441e89c6d7d02f13a38ac0de1c3a6ca5bd2fd74c52` |
