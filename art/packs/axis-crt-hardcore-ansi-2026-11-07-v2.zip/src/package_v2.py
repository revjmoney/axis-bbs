#!/usr/bin/env python3
import os,zipfile,hashlib,json
R=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
Z=os.path.dirname(R)+'/axis-crt-hardcore-ansi-2026-11-07-v2.zip'
files=[]
for d,dirs,ns in os.walk(R):
    dirs[:]=sorted(n for n in dirs if n!='__pycache__')
    for n in sorted(ns):
        if n.endswith(('.zip','.pyc')) or n=='archive_integrity.json':continue
        files.append(os.path.join(d,n))
files.sort()
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files:
        info=zipfile.ZipInfo(os.path.relpath(f,R),(2026,11,7,10,37,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,open(f,'rb').read(),compresslevel=9)
with zipfile.ZipFile(Z) as z:
    names=z.namelist();r={'zip':Z,'sha256':hashlib.sha256(open(Z,'rb').read()).hexdigest(),'size_bytes':os.path.getsize(Z),'file_count':len(names),
      'crc_all_ok':z.testzip() is None,'ans_count':len([n for n in names if n.startswith('ans/') and n.endswith('.ans')]),
      'actual_render_count':len([n for n in names if n.startswith('previews/') and n.rsplit('/',1)[-1][:2].isdigit() and n.endswith('.png')]),
      'all_entries_match_working_files':all(z.read(os.path.relpath(f,R))==open(f,'rb').read() for f in files),'fixed_deterministic_zip_metadata':True}
assert r['crc_all_ok'] and r['ans_count']==13 and r['actual_render_count']==13 and r['all_entries_match_working_files']
open(R+'/archive_integrity.json','w').write(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
