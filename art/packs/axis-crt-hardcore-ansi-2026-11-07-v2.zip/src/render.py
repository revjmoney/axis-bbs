"""Minimal ANSI (CP437, 16-colour) emulator + PNG renderer. Block/shade glyphs drawn
procedurally on the 8x16 VGA cell grid (seam-free); other glyphs from Terminus bitmap TTF."""
import re,sys
from PIL import Image,ImageDraw,ImageFont
PAL=[(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),
     (85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)]
A2V=[0,4,2,6,1,5,3,7]
FONT='/usr/share/fonts/truetype/terminus/TerminusTTF-4.46.0.ttf'
def emulate(data,cols=80,rows=25):
    s=data.split(b'\x1aSAUCE')[0].decode('cp437')
    g=[[(' ',7,0) for _ in range(cols)] for _ in range(rows)]
    x=y=0;fg,bg,bold=7,0,0;wrap=False;maxy=0;i=0;warn=[];sb=[]
    while i<len(s):
        c=s[i]
        if c=='\x1b':
            m=re.match(r'\x1b\[([0-9;?]*)([A-Za-z])',s[i:])
            if not m: warn.append('bad esc');i+=1;continue
            p=[int(v) if v else 0 for v in m.group(1).split(';')] if m.group(1) else []
            k=m.group(2);i+=m.end();wrap=False
            if k=='m':
                for v in p or [0]:
                    if v==0: fg,bg,bold=7,0,0
                    elif v==1: bold=1
                    elif 30<=v<=37: fg=A2V[v-30]
                    elif 40<=v<=47: bg=A2V[v-40]
                    else: warn.append('sgr %d'%v)
            elif k=='H': y=(p[0] if p else 1)-1; x=(p[1] if len(p)>1 else 1)-1
            elif k=='C': x=min(cols-1,x+(p[0] if p else 1))
            elif k=='A': y=max(0,y-(p[0] if p else 1))
            elif k=='B': y=min(rows-1,y+(p[0] if p else 1))
            elif k=='J': g=[[(' ',7,0) for _ in range(cols)] for _ in range(rows)]
            else: warn.append('csi '+k)
            continue
        i+=1
        if c=='\r': x=0;wrap=False;continue
        if c=='\n':
            y+=1;wrap=False
            if y>=rows: warn.append('scroll');sb.append(g.pop(0));g.append([(' ',7,0)]*cols);y=rows-1
            continue
        if wrap: x=0;y+=1;wrap=False
        if y>=rows: warn.append('scroll');sb.append(g.pop(0));g.append([(' ',7,0)]*cols);y=rows-1
        g[y][x]=(c,fg+8*bold,bg);maxy=max(maxy,y)
        if x==cols-1: wrap=True
        else: x+=1
    emulate.scrollback=sb
    return g,maxy,(y,x),warn
_f=None
def glyph(d,c,x0,y0,col):
    global _f
    W,H=8,16
    def R(a,b,cc,dd): d.rectangle([x0+a,y0+b,x0+cc-1,y0+dd-1],fill=col)
    if c=='█':R(0,0,8,16)
    elif c=='▀':R(0,0,8,8)
    elif c=='▄':R(0,8,8,16)
    elif c=='▌':R(0,0,4,16)
    elif c=='▐':R(4,0,8,16)
    elif c in '░▒▓':
        for yy in range(16):
            for xx in range(8):
                on={'░':(xx%4==(0 if yy%2==0 else 2)) and True,'▒':(xx+yy)%2==0,'▓':not((xx%4==(1 if yy%2==0 else 3)))}[c]
                if c=='░':on=(yy%2==0 and xx%4==0) or (yy%2==1 and xx%4==2)
                if on:d.point((x0+xx,y0+yy),fill=col)
    elif c in '─━═│║┌┐└┘├┤┬┴┼╔╗╚╝╠╣╦╩╬':
        h='─├┤┬┴┼┌┐└┘═╔╗╚╝╠╣╦╩╬';L=R_=U=D=0
        if c in '─┴┬┼═╩╦╬':L=R_=1
        if c in '│┤├┼║╣╠╬':U=D=1
        if c in '┌╔':R_=D=1
        if c in '┐╗':L=D=1
        if c in '└╚':R_=U=1
        if c in '┘╝':L=U=1
        if c in '├╠':R_=1
        if c in '┤╣':L=1
        if c in '┬╦':D=1
        if c in '┴╩':U=1
        dbl=c in '═║╔╗╚╝╠╣╦╩╬'
        offs=[-2,1] if dbl else [0]
        for o in offs:
            if L:R(0,7+o,4,8+o)
            if R_:R(3,7+o,8,8+o)
            if U:R(3+o,0,4+o,8)
            if D:R(3+o,7,4+o,16)
    elif c not in ' \x00':
        if _f is None:_f=ImageFont.truetype(FONT,16)
        d.text((x0,y0),c,font=_f,fill=col)
def png(g,path,rows=None,scale=1):
    rows=rows or len(g);im=Image.new('RGB',(80*8,rows*16));d=ImageDraw.Draw(im)
    for y in range(rows):
        for x in range(80):
            c,f,b=g[y][x];d.rectangle([x*8,y*16,x*8+7,y*16+15],fill=PAL[b]);glyph(d,c,x*8,y*16,PAL[f])
    if scale!=1: im=im.resize((im.width*scale,im.height*scale),Image.NEAREST)
    im.save(path);return im
if __name__=='__main__':
    g,my,cur,w=emulate(open(sys.argv[1],'rb').read());png(g,sys.argv[2]);print(my,cur,w)
