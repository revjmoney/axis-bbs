#!/usr/bin/env python3
"""Typography-only regression audit. Strict whole-cell identity includes character, foreground, background."""
import os,re,sys,json,hashlib,subprocess
import render,build_v2 as K
R=K.ROOT
sha=lambda b:hashlib.sha256(b).hexdigest()
def runbuild():
    subprocess.run([sys.executable,R+'/src/build_v2.py'],check=True,capture_output=True)
    return {n:sha(open(R+'/ans/'+n,'rb').read()) for n in sorted(os.listdir(R+'/ans')) if n.endswith('.ans')}
a=runbuild();b=runbuild();baseline=json.load(open(R+'/assets/v1_baseline_cells.json'));regions=json.load(open(R+'/header_edit_regions.json'))
contract=json.load(open(R+'/assets/source_contract.json'));preserved=json.load(open(R+'/assets/preserved_v1_files.json'))
res={'all_passed':False,'count':len(a),'deterministic':a==b,'scope':'Local emulator only; not BBS/telnet/CYD tested.',
     'all_existing_v1_files_byte_identical':all(os.path.exists(n) and sha(open(n,'rb').read())==h for n,h in preserved.items()),'files':{}}
oldzip=os.path.dirname(R)+'/axis-crt-hardcore-ansi-2026-11-07.zip'
res['delivered_v1_zip_sha256']=sha(open(oldzip,'rb').read())
res['delivered_v1_zip_unchanged']=res['delivered_v1_zip_sha256']==preserved[oldzip]
for n,h in a.items():
    raw=open(R+'/ans/'+n,'rb').read();s=raw.decode('cp437');inline='inline' in n
    g,my,cur,w=render.emulate(raw,rows=24);sb=list(render.emulate.scrollback)
    rows=12 if inline else 24
    allowed={tuple(c) for c in regions[n]['allowed_cells_1based']}
    outside=[(y+1,x+1) for y in range(rows) for x in range(80) if (y+1,x+1) not in allowed and list(g[y][x])!=baseline[n][y][x]]
    changed=[(y+1,x+1) for y in range(rows) for x in range(80) if list(g[y][x])!=baseline[n][y][x]]
    seq=re.findall(r'\x1b\[([0-9;]*)([A-Za-z])',s)
    r={'sha256':h,'heading':regions[n]['heading'],'allowed_bounds_1based':regions[n]['allowed_bounds_1based'],
       'allowed_header_cells':len(allowed),'changed_cells':len(changed),'outside_header_cells_checked':80*rows-len(allowed),
       'outside_header_changed_cells':len(outside),'approved_body_cell_identical':not outside,
       'all_edits_within_documented_header_mask':all(c in allowed for c in changed),'heading_has_actual_changes':len(changed)>0,
       'cp437_roundtrip':s.encode('cp437')==raw,'controls_whitelisted':all(ord(c)>=32 or c in '\x1b\r\n' for c in s),
       'all_escapes_valid_csi':s.count('\x1b')==len(seq),'csi_whitelisted':{k for p,k in seq}<=( {'m'} if inline else {'m','H','J'}),
       'classic_sgr_no_blink_ice_truecolor':all(int(v) in {0,1,30,32,37,40,42,47} for p,k in seq if k=='m' for v in p.split(';') if v),
       'positions_within_80x24':all(len(p.split(';'))==2 and 1<=int(p.split(';')[0])<=24 and 1<=int(p.split(';')[1])<=80 for p,k in seq if k=='H' and p),
       'palette_ok':all(f in {0,2,7,8,10,15} and bg in {0,2,7} for row in g for _,f,bg in row),
       'no_scroll_24':not w and not sb and my<rows,'end_cursor':[cur[0]+1,cur[1]+1]}
    _,_,_,ww=render.emulate(raw,rows=25);r['no_scroll_25']=not ww and not render.emulate.scrollback
    expected=[24,1] if 'splash' in n else contract[n]['original_end_cursor']
    r['end_cursor_matches_contract']=r['end_cursor']==expected
    def text_at(row,col,text):return ''.join(g[row-1][col-1+i][0] for i in range(len(text)))==text
    r['function_text_coordinates_preserved']=all(text_at(q['row'],q['col'],q['text']) for q in contract[n]['function_text_placements'])
    if inline:r['inline_twelve_rows_no_clear_or_cursor']=s.count('\r\n')==11 and {k for p,k in seq}<={'m'}
    elif 'splash' not in n:r['macro_row6_col51_preserved']=text_at(6,51,'%BN  node %NN')
    if any(q['row']==22 for q in contract[n]['function_text_placements']):r['host_menu_rows9_21_cols4_44_blank']=all(g[y][x][0]==' ' and g[y][x][2]==0 for y in range(8,21) for x in range(3,44))
    r['all_passed']=all(v for v in r.values() if isinstance(v,bool))
    res['files'][n]=r
res['body_cells_compared']=sum(v['outside_header_cells_checked'] for v in res['files'].values())
res['body_cells_changed']=sum(v['outside_header_changed_cells'] for v in res['files'].values())
res['all_passed']=len(a)==13 and a==b and res['all_existing_v1_files_byte_identical'] and res['delivered_v1_zip_unchanged'] and all(v['all_passed'] for v in res['files'].values())
print(json.dumps(res,indent=2))
if not res['all_passed']:sys.exit(1)
