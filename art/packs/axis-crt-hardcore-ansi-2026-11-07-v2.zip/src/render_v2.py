#!/usr/bin/env python3
import os,json
from PIL import Image,ImageDraw,ImageFont
import render,build_v2 as K
R=K.ROOT;P=R+'/previews';os.makedirs(P,exist_ok=True)
base=json.load(open(R+'/assets/v1_baseline_cells.json'));font=ImageFont.truetype(render.FONT,16)
images=[];headers=[]
for n,title,texts,h in K.V.MANIFEST:
    g,_,_,_=render.emulate(open(R+'/ans/'+n+'.ans','rb').read(),rows=24)
    rows=12 if 'inline' in n else 24
    im=render.png(g,P+'/'+n+'.png',rows=rows);images.append((n,im))
    if n[:2] in ('01','04','05','08','10'):render.png(g,P+'/HERO_'+n+'_2x.png',rows=rows,scale=2)
    old=render.png(base[n+'.ans'],P+'/temp.png',rows=rows)
    ch=192 if n[:2] in ('01','02') else 112
    # 1x source-pixel crops preserve normal terminal scale, labels outside art.
    headers.append((n,old.crop((0,0,640,ch)),im.crop((0,0,640,ch))))
    if n[:2]=='01':
        out=Image.new('RGB',(1280,416),(9,12,9));d=ImageDraw.Draw(out)
        d.text((8,8),'APPROVED ART / original lettering',font=font,fill=(150,240,150));d.text((648,8),'V2 / clearer lettering, same body',font=font,fill=(150,240,150))
        out.paste(old,(0,32));out.paste(im,(640,32));out.save(P+'/splash_before_after_v2.png')
os.remove(P+'/temp.png')
sheet=Image.new('RGB',(1232,1388),(9,12,9));d=ImageDraw.Draw(sheet)
for i,(n,im) in enumerate(images):
    x=8+i%3*408;y=8+i//3*276;d.text((x,y),n,font=font,fill=(150,240,150))
    sheet.paste(im.resize((400,im.height*400//640),Image.Resampling.NEAREST),(x,y+22))
sheet.save(P+'/contact_sheet_hardcore_v2_13.png')
height=sum(a.height+36 for _,a,b in headers)+32
out=Image.new('RGB',(1280,height),(9,12,9));d=ImageDraw.Draw(out)
d.text((8,8),'V1 / BEFORE',font=font,fill=(150,240,150));d.text((648,8),'V2 / AFTER',font=font,fill=(150,240,150));y=32
for n,a,b in headers:
    d.text((8,y),n,font=font,fill=(150,240,150));d.text((648,y),n,font=font,fill=(150,240,150));out.paste(a,(0,y+24));out.paste(b,(640,y+24));y+=a.height+36
out.save(P+'/all_13_header_crops_before_after_v2.png')
print('13 actual PNGs, 5 heroes, contact sheet, 13 before/after header pairs, splash comparison')
