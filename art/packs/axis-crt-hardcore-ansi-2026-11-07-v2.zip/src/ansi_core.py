#!/usr/bin/env python3
"""Axis Micro BBS - underground ANSI pack generator (reproducible, no randomness without seed).
Writes 80-col CP437 .ANS files using classic 16-colour SGR only (30-37/40-47 + bold for bright fg).
Run:  python3 build_pack.py   (outputs ../ans/*.ans)"""
import math,os,random
V2A=[0,4,2,6,1,5,3,7]   # VGA colour index -> ANSI SGR digit
W=80
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')

# ---------------- 5x8 display font (each pixel = 2 columns x 1 half-row) -------------
F={
'A':[".###.","#...#","#...#","#####","#...#","#...#","#...#","#...#"],
'X':["#...#","#...#",".#.#.","..#..","..#..",".#.#.","#...#","#...#"],
'I':["#####","..#..","..#..","..#..","..#..","..#..","..#..","#####"],
'S':[".####","#....","#....",".###.","....#","....#","....#","####."],
'M':["#...#","##.##","#.#.#","#.#.#","#...#","#...#","#...#","#...#"],
'T':["#####","..#..","..#..","..#..","..#..","..#..","..#..","..#.."],
'R':["####.","#...#","#...#","####.","#.#..","#..#.","#...#","#...#"],
'D':["####.","#...#","#...#","#...#","#...#","#...#","#...#","####."],
'O':[".###.","#...#","#...#","#...#","#...#","#...#","#...#",".###."],
'L':["#....","#....","#....","#....","#....","#....","#....","#####"],
'G':[".###.","#...#","#....","#....","#.###","#...#","#...#",".###."],
'N':["#...#","##..#","##..#","#.#.#","#.#.#","#..##","#..##","#...#"],
'P':["####.","#...#","#...#","####.","#....","#....","#....","#...."],
'Y':["#...#","#...#",".#.#.","..#..","..#..","..#..","..#..","..#.."],
'F':["#####","#....","#....","####.","#....","#....","#....","#...."],
'E':["#####","#....","#....","####.","#....","#....","#....","#####"],
'C':[".###.","#...#","#....","#....","#....","#....","#...#",".###."],
'H':["#...#","#...#","#...#","#####","#...#","#...#","#...#","#...#"],
'U':["#...#","#...#","#...#","#...#","#...#","#...#","#...#",".###."],
'W':["#...#","#...#","#...#","#.#.#","#.#.#","#.#.#","##.##","#...#"],
'B':["####.","#...#","#...#","####.","#...#","#...#","#...#","####."],
}
THEMES={ # face ramp: 4 (bright,dark) pairs top->bottom; accent; texture colours
 'steel':  dict(r=[15,7,11,3,9,1,8,0],  acc=11,warm=14,t1=1,t2=8),
 'violet': dict(r=[15,7,13,5,9,1,8,0],  acc=13,warm=14,t1=5,t2=1),
 'ember':  dict(r=[15,7,14,6,12,4,13,5],acc=14,warm=12,t1=5,t2=1),
 'acid':   dict(r=[15,7,11,3,10,2,9,1], acc=10,warm=14,t1=2,t2=1),
 'ice':    dict(r=[15,7,11,3,9,1,13,5], acc=11,warm=14,t1=1,t2=5),
}
def dark(c): return 0 if c==8 else (c-8 if c>7 else c)

class Canvas:
    def __init__(s,rows,tex):
        s.R=rows;s.cell=[[None]*W for _ in range(rows)];s.px=[[None]*W for _ in range(rows*2)];s.tex=tex;s.blank=set()
    def p(s,hy,x,c):
        if 0<=hy<s.R*2 and 0<=x<W: s.px[hy][x]=c
    def put(s,y,x,text,fg,bg=0):
        for i,ch in enumerate(text):
            if 0<=x+i<W and 0<=y<s.R: s.cell[y][x+i]=(ch,fg,bg)
    def clear(s,y0,y1,x0,x1):   # black window, removes pixels & texture
        for y in range(y0,y1+1):
            for x in range(x0,x1+1):
                s.cell[y][x]=None;s.px[2*y][x]=s.px[2*y+1][x]=None;s.blank.add((y,x))
    def final(s):
        g=[]
        for y in range(s.R):
            row=[]
            for x in range(W):
                if s.cell[y][x] is not None: row.append(s.cell[y][x]);continue
                t,b=s.px[2*y][x],s.px[2*y+1][x]
                if t is None and b is None: row.append((' ',7,0) if (y,x) in s.blank else s.tex(x,y))
                elif t==b: row.append(('█',t,0))
                elif b is None: row.append(('▀',t,0))
                elif t is None: row.append(('▄',b,0))
                elif b<=7: row.append(('▀',t,b))
                elif t<=7: row.append(('▄',b,t))
                else: row.append(('▀',t,dark(b)))
            g.append(row)
        return g

def logo(cv,word,x0,hy0,th,sx=2,sy=1,slant=True,shadow=True):
    """Extruded italic logo: far shadow layer, near shadow layer, ramp-shaded face, edge highlights."""
    r=th['r'];H=8*sy
    pts={}
    cx=x0
    for ch in word:
        if ch==' ': cx+=3*sx;continue
        bm=F[ch]
        for fy,line in enumerate(bm):
            for fx,v in enumerate(line):
                if v=='#':
                    for yy in range(sy):
                        hy=fy*sy+yy; off=((7-fy)//3)*(sx//2 or 1) if slant else 0
                        for xx in range(sx): pts[(hy,cx+fx*sx+xx+off)]=1
        cx+=5*sx+3
    if shadow:
        for (hy,x) in pts: cv.p(hy0+hy+2,x+2,th['t2'] if th['t2'] not in (0,8) else 1)  # far extrusion layer
        for (hy,x) in pts: cv.p(hy0+hy+1,x+1,8)                                         # near extrusion layer
    for (hy,x) in pts:
        c=r[min(7,hy*8//H)]
        if (hy-1,x) not in pts: c=15 if hy*8//H<5 else th['acc']   # top-lit bevel highlight
        if (hy+1,x) not in pts and hy*8//H>=4: c=r[7] if r[7]!=0 else 8
        cv.p(hy0+hy,x,c)
    return cx
def emit(g,full=True,tail='',inline_last_cols=75):
    out=['\x1b[0m'];st=None
    if full: out.append('\x1b[2J\x1b[H')
    for y,row in enumerate(g):
        if full: out.append('\x1b[%d;1H'%(y+1))
        n=(inline_last_cols if not full and y==len(g)-1 else W-1) if (y==len(g)-1 or not full) else W   # never write column 80 on last row / inline rows
        for ch,fg,bg in row[:n]:
            assert 0<=bg<=7 and 0<=fg<=15; s=(fg,bg)
            if s!=st:
                out.append('\x1b[0;%s3%d;4%dm'%('1;' if fg>7 else '',V2A[fg&7],V2A[bg]));st=s
            out.append(ch)
        if not full and y<len(g)-1: out.append('\x1b[0m\r\n');st=None
    out.append('\x1b[0m');out.append(tail)
    return ''.join(out).encode('cp437')
