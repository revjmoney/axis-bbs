#!/usr/bin/env python3
"""RUPTURE v2: typography-only revision. Approved body copied cell-for-cell from recorded v1.
The editable body generator is bundled as body_v1.py, unchanged from the approved version.
Exact allowed cells = union of old heading writes and new heading writes (including their outline).
"""
import os,json
import body_v1 as V
import ansi_core as B
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GLYPHS={
'A':['.###.','#...#','#...#','#####','#...#','#...#','#...#'],
'X':['#...#','#...#','.#.#.','..#..','.#.#.','#...#','#...#'],
'I':['###','.#.','.#.','.#.','.#.','.#.','###'],
'S':['.####','#....','#....','.###.','....#','....#','####.'],
'L':['#....','#....','#....','#....','#....','#....','#####'],
'O':['.###.','#...#','#...#','#...#','#...#','#...#','.###.'],
'G':['.####','#....','#....','#.###','#...#','#...#','.###.'],
'N':['#...#','##..#','##..#','#.#.#','#..##','#..##','#...#'],
'P':['####.','#...#','#...#','####.','#....','#....','#....'],
'Y':['#...#','#...#','.#.#.','..#..','..#..','..#..','..#..'],
'D':['####.','#...#','#...#','#...#','#...#','#...#','####.'],
'R':['####.','#...#','#...#','####.','#.#..','#..#.','#...#'],
'M':['#...#','##.##','#.#.#','#...#','#...#','#...#','#...#'],
'E':['#####','#....','#....','####.','#....','#....','#####'],
'F':['#####','#....','#....','####.','#....','#....','#....'],
'T':['#####','..#..','..#..','..#..','..#..','..#..','..#..'],
'H':['#...#','#...#','#...#','#####','#...#','#...#','#...#']}
ORIGINAL=V.thorn_type

def clear_type(cv,word,x0,y0,scale=1,seed=0):
    """Consistent baseline, separated angular cores, open counters, restrained shear and bevel.
    Decorations consist of the rear extrusion and exterior keyline, never through letter interiors.
    """
    big=scale==2;y0=0
    sy=2 if big else 1
    height=18 if big else 7
    pts=set();backing=set();cx=x0+(0 if big else 0)
    for ch in word:
        rows=GLYPHS[ch]
        if big:rows=rows[:2]+[rows[1]]+rows[2:6]+[rows[5]]+rows[6:]
        for gy,row in enumerate(rows):
            for iy in range(sy):
                yy=gy*sy+iy
                shear=(height-1-yy)//(7 if big else 4)
                for bx in range(len(row)*2):backing.add((y0+yy,cx+bx+shear))
                for gx,v in enumerate(row):
                    if v=='#':
                        for ix in range(2):pts.add((y0+yy,cx+gx*2+ix+shear))
        cx+=len(rows[0])*2+3
    # Clean negative-space counters: rear cables must not masquerade as strokes inside O/A/P/R.
    for y,x in backing:cv.p(y,x,0)
    # Short rear extrusion sits behind the cores and respects the inter-letter air gaps.
    for dy,dx,c in [(2,1,2),(1,1,8)]:
        for y,x in pts:
            if big or y+dy<10:cv.p(y+dy,x+dx,c)
    # Carve a one-pixel black keyline without letting it cross a letter core.
    for y,x in pts:
        for dy,dx in ((-1,0),(1,0),(0,-1),(0,1)):
            yy,xx=y+dy,x+dx
            if (yy,xx) not in pts and (big or 0<=yy<10):cv.p(yy,xx,0)
    for y,x in sorted(pts):
        yy=y-y0
        ramp=[15,7,10,10,10,10,2] if not big else [15,7,7,10,10,2,2,10,2]
        c=ramp[min(len(ramp)-1,yy//sy)]
        # Dark lower chamfer; top-edge priority keeps one-pixel crossbars luminous and readable.
        if (y+1,x) not in pts:c=2
        if (y-1,x) not in pts:c=15 if yy<height*.5 else 10
        cv.p(y,x,c)


def normalized(g):return [[tuple(c) for c in row] for row in g]
def build():
    os.makedirs(ROOT+'/ans',exist_ok=True)
    baseline=json.load(open(ROOT+'/assets/v1_baseline_cells.json'))
    region={}
    for i,(name,title,texts,h) in enumerate(V.MANIFEST):
        name+='.ans';writes=set()
        def replacement(cv,*args,**kw):
            # Record the old heading footprint without changing the approved backing artwork.
            test=V.Canvas(cv.R);oldp=test.p
            def oldrecord(y,x,c):
                if 0<=y<cv.R*2 and 0<=x<80:writes.add((y//2,x))
                oldp(y,x,c)
            test.p=oldrecord;ORIGINAL(test,*args,**kw)
            actual=cv.p
            def newrecord(y,x,c):
                if 0<=y<cv.R*2 and 0<=x<80:writes.add((y//2,x))
                actual(y,x,c)
            cv.p=newrecord
            clear_type(cv,*args,**kw)
            cv.p=actual
        V.thorn_type=replacement
        try:cv=V.splash() if i==0 else V.inline() if i==1 else V.functional(i,title,texts)
        finally:V.thorn_type=ORIGINAL
        revised=cv.final();old=normalized(baseline[name]);g=[]
        for y,row in enumerate(old):
            g.append([revised[y][x] if (y,x) in writes else old[y][x] for x in range(80)])
        # Copy approved full-cell body records verbatim outside the narrowly recorded heading mask.
        tail='\x1b[24;1H' if i==0 else '' if i==1 else V.tail(texts)
        data=B.emit(g,i!=1,tail)
        open(ROOT+'/ans/'+name,'wb').write(data)
        changed=[(y,x) for y in range(len(g)) for x in range(80) if g[y][x]!=old[y][x]]
        region[name]={'allowed_cells_1based':[[y+1,x+1] for y,x in sorted(writes)],
          'allowed_cell_count':len(writes),'changed_cell_count':len(changed),
          'allowed_bounds_1based':[min(y for y,x in writes)+1,max(y for y,x in writes)+1,min(x for y,x in writes)+1,max(x for y,x in writes)+1],
          'method':'Exact union of old/new heading drawing writes, rounded to character cells; all other cells copied unchanged from approved v1.',
          'heading':title}
    open(ROOT+'/header_edit_regions.json','w').write(json.dumps(region,indent=2)+'\n')
    return region
if __name__=='__main__':
    r=build()
    for n,v in r.items():print(n,v['heading'],v['allowed_bounds_1based'],v['changed_cell_count'])
