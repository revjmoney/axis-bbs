#!/usr/bin/env python3
"""RUPTURE / AXIS: CP437 underground CRT artwork. No terminal extensions.
Original case, lettering, cables, shards and composition; face density study from owner reference.
All positions zero-based in artwork; host text coordinates one-based in MANIFEST.
"""
import os, math, json
import numpy as np
from scipy import ndimage
from PIL import Image, ImageFilter, ImageDraw
import ansi_core as B
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=ROOT+'/ans'
PAL={0,2,7,8,10,15}
class Canvas(B.Canvas):
    def __init__(self,rows=24):super().__init__(rows,lambda x,y:(' ',7,0))
    def p(self,y,x,c):
        # Pixel layer writes may occlude previous density-glyph layers.
        if 0<=y<self.R*2 and 0<=x<80:
            r=y//2
            if self.cell[r][x] is not None:
                ch,f,b=self.cell[r][x];self.cell[r][x]=None
                self.px[r*2][x]=f if ch!=' ' else b;self.px[r*2+1][x]=f if ch!=' ' else b
            self.px[y][x]=c

def polygon(cv,points,kind='metal',seed=0):
    """Broken flat metal, bevelled only at the visible perimeter (not a uniform silver band)."""
    mask=Image.new('1',(80,cv.R*2));ImageDraw.Draw(mask).polygon(points,fill=1)
    ar=np.asarray(mask);inside=ndimage.distance_transform_edt(ar)
    for y,x in zip(*np.where(ar)):
        edge=inside[y,x]
        if kind=='void':c=0
        elif kind=='glass':c=2 if x%7==0 and y%3==0 else 0
        elif kind=='shard':c=7 if edge<1.5 else 2
        else:
            if edge<1.1:c=7 if (x+y+seed)%7 else 15
            elif edge<2.1:c=8
            else:c=8 if (x+2*y)//4%3 else 0
        cv.p(y,x,c)
    if kind=='metal':
        # Broad metal planes get curved density transitions; edge pixels remain sharp half-blocks.
        for r in range(cv.R):
            for x in range(80):
                if inside[2*r,x]>=1.9 and inside[2*r+1,x]>=1.9:
                    e=min(inside[2*r,x],inside[2*r+1,x])
                    if e<3: cv.put(r,x,'▓',8,0)
                    else: cv.put(r,x,'▒' if (x+2*r-seed)%9<4 else '░',7,8 if False else 0)
    return ar

def line(cv,pts,color=7,width=1):
    im=Image.new('1',(80,cv.R*2));d=ImageDraw.Draw(im);d.line(pts,fill=1,width=width)
    for y,x in zip(*np.where(np.asarray(im))):cv.p(y,x,color)

def cord(cv,pts,green=False,thick=3):
    """Black separation, ribbed charcoal body, staggered helical highlights; true foreground occlusion."""
    line(cv,[(x+1,y+1) for x,y in pts],0,thick+3)
    line(cv,pts,8,thick)
    line(cv,[(x-1,y-1) for x,y in pts],2 if green else 7,1)
    # localized ribbed glints along the segments, not random texture
    t=0
    for (x,y),(xx,yy) in zip(pts,pts[1:]):
        n=max(abs(xx-x),abs(yy-y),1)
        for i in range(n):
            if t%4==0:cv.p(round(y+(yy-y)*i/n),round(x+(xx-x)*i/n),10 if green else 15)
            t+=1

def thorn_type(cv,word,x0,y0,scale=1,seed=0):
    """Individually leaning/sinking glyphs, irregular interlocking spikes, cut-back bevel, offset extrusion.
    The scale=2 AXIS master uses drawn angular paths rather than enlarged bitmap headings.
    """
    if word=='AXIS' and scale==2:
        # 49 x 18 custom thorn logotype: tall needle A, slash X, hooked I, broken lightning S.
        shapes=[[(0,20),(10,0),(17,2),(16,20),(11,16),(12,10),(7,10),(4,18)],
                [(12,1),(18,4),(24,11),(34,0),(29,12),(35,21),(27,18),(23,15),(15,24),(19,13)],
                [(29,3),(44,0),(37,5),(33,16),(39,16),(28,23),(28,19),(31,7),(27,8)],
                [(43,1),(56,0),(51,5),(44,5),(42,9),(51,7),(50,12),(44,20),(33,23),(39,18),(44,17),(46,13),(37,15),(39,7)]]
        pts=set()
        im=Image.new('1',(80,48));d=ImageDraw.Draw(im)
        for sh in shapes:d.polygon([(x0+x,y0+y) for x,y in sh],fill=1)
        # A counter, small slashed internal notches
        d.polygon([(x0+9,y0+7),(x0+12,y0+3),(x0+12,y0+7)],fill=0)
        pts={(y0+round((y-y0)*.84),x0+round((x-x0)*.80)) for y,x in zip(*np.where(np.asarray(im)))}
        H=20
    else:
        pts=set();cx=x0
        for k,ch in enumerate(word):
            bm=B.F[ch]
            for fy,row in enumerate(bm):
                # 8-high letter, skew and varying baseline create a moving rather than typeset silhouette.
                yy=y0+fy+([0,1,-1,0,1,-1][(k+seed)%6])
                shift=(7-fy)//2+(1 if fy in (3,4) and k%2 else 0)
                for fx,v in enumerate(row):
                    if v=='#':pts.add((yy,cx+fx*2+shift));pts.add((yy,cx+fx*2+shift+1))
            # spear terminals hook through the neighboring extrusion
            for j in range(3):pts.add((y0-1+j,cx+10-j));pts.add((y0+7+j,cx+1-j))
            cx+=10 if ch=='I' else 11
        H=10
    # extrusion in dark green, with black stroke separating the interlocked faces
    for dy,dx,c in [(3,3,2),(2,2,8),(1,1,0)]:
        for y,x in pts:cv.p(y+dy,x+dx,c)
    for y,x in pts:
        yy=y-y0
        c=[15,7,7,10,2,10,2,8,7,2][int(max(0,min(9,yy*10/max(H,1))))]
        if (y-1,x) not in pts:c=15 if yy<H*.55 else 10
        if (y+1,x) not in pts:c=8 if yy>H*.5 else 2
        cv.p(y,x,c)
    # narrow incised stripes; selective, not a repeating rule across the screen
    if scale==2:
        line(cv,[(x0+4,y0+17),(x0+10,y0+6)],0)
        line(cv,[(x0+24,y0+11),(x0+31,y0+4)],0)

# Density ramps use only ordinary foreground + low background ANSI colors.
RAMP=[(' ',7,0),('░',2,0),('▒',2,0),('▓',2,0),('█',2,0),
      ('░',10,2),('▒',10,2),('▓',10,2),('█',10,0),('░',15,2),('▒',15,10 if False else 2),('▓',15,2),('█',15,0)]

def load_face():
    im=Image.open(ROOT+'/assets/skull-reference.webp').convert('L')
    # Remove tiny background stars/outline segments before sampling; preserve dense stippled gradients.
    a=np.asarray(im.filter(ImageFilter.GaussianBlur(2.2)),dtype=float)/255
    lab,n=ndimage.label(a>.095)
    sizes=np.bincount(lab.ravel());keep=sizes>180;keep[0]=False
    silhouette=ndimage.binary_fill_holes(ndimage.binary_closing(keep[lab],iterations=3))
    a=a*silhouette
    # Remove the thin dashed outline to the left, rather than treating it as part of the head.
    a[:,:132]=0;a[:,426:]=0;a[:43]=0
    return Image.fromarray(np.uint8(a[43:538,132:426]*255))
FACE=load_face()

def skull(cv,cx,cy,w,h,tilt=0.10,mirror=False,bone=False,scream=False):
    """Reference density silhouette sampled on half cells, but full cells use ordered shade density.
    Black eye/nose/mouth cavities are zeros, never colored 'black' dots in a luminous face.
    """
    source=FACE.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if mirror else FACE
    # Sampling at 4 subpixels per half-cell retains void edges.
    a=np.asarray(source.resize((w*4,h*4),Image.Resampling.LANCZOS),dtype=float)/255
    # Perspective makes the cheek closest to the viewer wider than the far temple.
    x0=round(cx-w/2);y0=round(cy-h/2)
    samples={};masks={}
    for y in range(h):
        for x in range(w):
            v=float(a[y*4:(y+1)*4,x*4:(x+1)*4].mean())
            # Gentle sidelight makes bone masses dimensional instead of white clip art.
            v*=0.60+0.40*(1-x/max(1,w-1))
            if v<.035:continue
            xx=round(x0+x+tilt*(y-h*.45));yy=round(y0+y)
            if not(0<=xx<80 and 0<=yy<cv.R*2):continue
            samples[(yy,xx)]=v;masks[(yy,xx)]=True
    # Black silhouette under the skull is broader than the light face; it erases glass / old bezel.
    sil=np.asarray(source.resize((w,h),Image.Resampling.BILINEAR))>10
    sil=ndimage.binary_fill_holes(sil)
    for y,x in zip(*np.where(sil)):
        xx=round(x0+x+tilt*(y-h*.45));yy=round(y0+y)
        cv.p(yy,xx,0)
    for r in range(cv.R):
        for x in range(80):
            vt=samples.get((2*r,x));vb=samples.get((2*r+1,x))
            if vt is None and vb is None:continue
            if vt is None or vb is None or abs(vt-vb)>.35:
                # Half-blocks describe broken silhouette, teeth and cavity boundaries, not boxy squares.
                for hy,v in [(r*2,vt),(r*2+1,vb)]:
                    if v is not None:cv.p(hy,x,15 if v>.78 else 10 if v>.45 else 2 if v>.14 else 8)
            else:
                v=(vt+vb)/2
                # Illuminate the frontal bone but leave side planes in dark green.
                k=max(1,min(len(RAMP)-1,round(v*(len(RAMP)-1))))
                if bone:
                    ramp=[('░',8,0),('▒',8,0),('▓',8,0),('█',8,0),('░',7,0),('▒',7,0),('▓',7,0),('█',7,0),('░',15,7),('▒',15,7),('▓',15,7),('█',15,0),('█',15,0)]
                    cv.put(r,x,*ramp[k])
                else:cv.put(r,x,*RAMP[k])
    if scream:
        # A displaced lower mandible exposes black space between it and the maxilla.
        y=int(cy+h*.28)
        line(cv,[(int(cx-w*.17),y),(int(cx+w*.20),y+1)],0,2)


def case(cv,x,y,w,h,variant=0):
    """Exploded trapezoidal CRT housing. Its top, side and chin are separate ripped polygons.
    The negative glass opening is never enclosed by a clean continuous rectangle.
    """
    # skewed rear volume / vents, hanging away from the face plane
    polygon(cv,[(x+6,y-2),(x+w-1,y+1),(x+w+2,y+h-4),(x+w-6,y+h+3),(x+3,y+h-2),(x-1,y+7)],'metal',variant)
    polygon(cv,[(x+4,y+3),(x+w-5,y+2),(x+w-2,y+h-7),(x+3,y+h-3),(x+1,y+10)],'glass')
    # Upper rail has a large torn-out center, and a sharp cantilever at left.
    polygon(cv,[(x-3,y+5),(x+2,y-1),(x+w-4,y),(x+w+1,y+3),(x+w-9,y+4),(x+w-13,y+2),(x+7,y+3),(x+4,y+7)],'metal',variant)
    # Left side is interrupted at the cheek, not a tube border.
    polygon(cv,[(x-2,y+8),(x+2,y+5),(x+3,y+11),(x,y+16),(x+3,y+19),(x-1,y+22),(x-3,y+14)],'metal',variant)
    polygon(cv,[(x+w-2,y+6),(x+w+3,y+10),(x+w+1,y+h-1),(x+w-6,y+h+3),(x+w-1,y+h-8),(x+w-4,y+17)],'metal',variant)
    # Splintered chin rolls OUT toward viewer; diagonal teeth in the metal.
    polygon(cv,[(x-1,y+h-5),(x+7,y+h-7),(x+11,y+h-3),(x+15,y+h-6),(x+20,y+h-1),(x+w-3,y+h-4),(x+w-7,y+h+3),(x+6,y+h+1)],'metal',variant)
    for k in range(3):line(cv,[(x+w-1,y+11+k*3),(x+w+2,y+12+k*3)],0)
    cv.p(y+h,x+w-9,10);cv.p(y+h,x+w-8,2)
    # Open fault-lines divide the housing into independent chunks.
    line(cv,[(x+10,y),(x+13,y+2),(x+11,y+4)],0)
    line(cv,[(x+w-4,y+17),(x+w,y+19)],0,2)


def shards(cv,cx,cy,s=1,variant=0):
    # Unequal long triangles, separated by black breathing space, with white edge only on one side.
    tris=[[(cx-11*s,cy-5*s),(cx-22*s,cy-15*s),(cx-16*s,cy-2*s)],
          [(cx+9*s,cy-8*s),(cx+16*s,cy-18*s),(cx+15*s,cy-6*s)],
          [(cx+13*s,cy+3*s),(cx+23*s,cy-1*s),(cx+16*s,cy+8*s)],
          [(cx-13*s,cy+9*s),(cx-22*s,cy+14*s),(cx-15*s,cy+4*s)]]
    for k,p in enumerate(tris):
        if variant%3==1 and k==0:continue
        p=[(round(x),round(y)) for x,y in p];polygon(cv,p,'shard')
        line(cv,[p[0],p[1]],15 if k%2==0 else 7)
    # Hairline cracks with a black keyline prevent the strands disappearing into the face.
    for pts in [[(cx-8,cy-8),(cx-13,cy-11),(cx-11,cy-15)],[(cx+9,cy+6),(cx+14,cy+8),(cx+19,cy+7)]]:
        line(cv,pts,0,2);line(cv,pts,7)

def rubble(cv,seed=0,full=False):
    # Deliberate clusters, not random static. These masses anchor the black negative space.
    if full:
        polygon(cv,[(0,35),(7,32),(11,35),(18,33),(24,40),(20,44),(4,43),(0,46)],'metal',seed)
        line(cv,[(0,37),(10,35),(18,38)],2,2)
    else:
        polygon(cv,[(47,14),(51,11),(58,13),(54,17),(49,19)],'metal',seed)
        polygon(cv,[(73,42),(78,38),(79,45),(68,45)],'metal',seed)

def upper(cv,title,seed):
    # Curved broken chassis ribs behind the typography run into the tube-side structure.
    cord(cv,[(0,7),(7,4),(19,5),(29,1),(45,4),(55,11),(69,13)],green=False,thick=2)
    thorn_type(cv,title.upper(),3,1,seed=seed)
    # the title's splinter reaches downward without becoming a horizontal separator
    line(cv,[(7,10),(5,13),(15,14),(24,12),(36,14),(47,12)],2)
    line(cv,[(6,11),(4,14),(15,15),(23,13)],8)
    cv.put(5,3,'// '+title.lower(),8)
    # Reserved macro is appended last; keep its immediate area visually quiet.
    cv.clear(5,5,49,65)

P22='arrows move, Enter picks, or press the key'
MANIFEST=[
 ('01_crt_splash_fullscreen','AXIS',[],'5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'),
 ('02_crt_logo_banner_inline','AXIS',[],'d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'),
 ('03_crt_axis_welcome','AXIS',[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_crt_axis_main_menu','AXIS',[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_crt_login','LOGIN',[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_crt_apply_new_user','APPLY',[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_crt_doors_menu','DOORS',[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_crt_messages_menu','MSGS',[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_crt_files_menu','FILES',[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_crt_matrix_menu','MATRIX',[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_crt_fast_menu','FAST',[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_crt_shop_screen','SHOP',[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_crt_mill_screen','MILL',[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855')]

def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;32mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for r,c,f,s in texts:t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if f>7 else '',B.V2A[f&7],s)
    return t

def splash():
    cv=Canvas();rubble(cv,full=True)
    # cable loom behind whole composition
    cord(cv,[(0,29),(10,24),(12,19),(21,14),(40,15),(57,9),(75,10),(79,6)],True,2)
    case(cv,35,9,40,29,0)
    shards(cv,59,24,1.0)
    # skull breaks its lower chin, left cheek, and upper rim simultaneously
    skull(cv,59,26,30,37,tilt=-.08)
    # Custom AXIS carving sinks into the broken case; more art left of face than blank margin.
    thorn_type(cv,'AXIS',0,0,2)
    # Local foreground left bezel torn free across the cheek, with face mostly unobscured.
    polygon(cv,[(30,27),(35,23),(41,25),(45,30),(40,32),(36,29),(31,32)],'metal')
    # Two braided foreground cable paths cross frame, logotype foot and jaw, proving overlap.
    cord(cv,[(0,41),(12,39),(21,31),(29,32),(37,42),(49,44),(62,42),(75,44),(79,39)],False,3)
    cord(cv,[(0,44),(13,42),(23,35),(30,36),(36,45),(48,47),(62,45),(76,47)],True,2)
    # Small separated shards in the black field, not ambient noise
    polygon(cv,[(6,28),(15,21),(12,29)],'shard');line(cv,[(6,28),(15,21)],15)
    polygon(cv,[(16,28),(26,19),(25,24),(33,21),(24,32),(25,26)],'metal')
    line(cv,[(17,28),(25,21)],10)
    cv.put(16,2,'c a r r i e r',8)
    cv.put(17,3,'//  LOST',2)
    cv.clear(22,23,0,79)
    cv.put(22,3,'// R U P T U R E',10);cv.put(22,46,'Axis Micro BBS Firmware',7)
    cv.put(23,3,'UNDERGROUND CNC',8);cv.put(23,58,'[ phosphor remains ]',2)
    return cv

def inline():
    cv=Canvas(12)
    case(cv,48,1,29,17)
    skull(cv,65,12,18,23,tilt=.12)
    thorn_type(cv,'AXIS',0,0,2)
    cord(cv,[(0,21),(17,19),(32,15),(44,18),(57,21),(70,18),(79,20)],True,2)
    cv.clear(11,11,0,79);cv.put(11,4,'A X I S   / /   U N D E R G R O U N D   C N C',7)
    return cv

# Unique pose and housing displacement per function: 11 deliberately related, not 11 clones.
POSE={
 2:(64,29,24,32,-.13,False),3:(64,28,24,32,.10,False),
 4:(63,28,25,34,-.10,False),5:(65,29,24,32,.16,True),
 6:(64,28,23,32,-.18,False),7:(64,28,25,33,.14,False),
 8:(63,28,23,32,-.08,True),9:(65,28,23,33,.08,False),
 10:(65,28,25,32,-.16,False),11:(64,28,25,34,.12,True),
 12:(64,28,25,33,-.12,False)}

def functional(i,title,texts):
    cv=Canvas();menu=texts[0][0]==22
    rubble(cv,i)
    cord(cv,[(2,19),(0,30),(2,36),(0,45),(12,46),(27,45),(43,47)],True,2)
    upper(cv,title,i)
    # Independent housing lean, ripped side and thrown fragments.
    case(cv,48+(i%3-1),16-(i%2),29,23,i)
    shards(cv,63,27,.72,i)
    cx,cy,w,h,tilt,mirror=POSE[i]
    if i==9:
        # Matrix: a second dark ghost skull fractured behind the near one.
        skull(cv,54,26,15,22,-.1,True,bone=True)
    skull(cv,cx,cy,w,h,tilt,mirror,scream=i in (7,12))
    # A torn side cheek shard sits in FRONT of the green face along its left margin.
    polygon(cv,[(46,28),(50,24),(54,27),(53,31),(48,34),(46,32)],'metal',i)
    # Grip-like cable enters the case, turns across cheek then hangs below broken chin.
    if i%3==0:
        pts=[(79,15),(75,18),(77,24),(73,29),(75,36),(68,40),(60,42),(48,39),(45,43)]
    elif i%3==1:
        pts=[(79,42),(73,39),(68,42),(58,41),(51,36),(48,29),(45,33),(47,39)]
    else:
        pts=[(79,26),(76,31),(77,38),(71,42),(60,43),(53,40),(49,34),(46,36)]
    cord(cv,pts,False,2)
    cord(cv,[(x,y+3) for x,y in pts],True,1)
    # Function-specific artifacts are carved into open space, never into host menu cells.
    if i==6: # door frame as a broken black portal running beside skull
        line(cv,[(48,19),(52,17),(52,22)],10)
        line(cv,[(47,21),(47,27)],2)
    if i==8: # loose data tracks / chips behind the hanging jaw
        for k in range(3):line(cv,[(46,39+k*2),(51,39+k*2)],2)
    if i==10:line(cv,[(76,13),(72,18),(76,18),(72,23)],15)
    if i==11:
        # lathe spindle / jack plug emerging under shattered chassis
        polygon(cv,[(27,35),(40,35),(46,39),(39,42),(27,40)],'metal')
        for x in (30,33,36):line(cv,[(x,35),(x,40)],7)
    if i==12:
        polygon(cv,[(29,33),(34,29),(42,33),(38,38),(32,40)],'metal')
        line(cv,[(32,32),(40,36)],10)
    # Clear host apertures, not boxed 'decorative menus'.
    if menu:
        cv.clear(8,20,3,43);cv.clear(21,21,3,43)
    else:
        for r,c,f,s in texts:cv.clear(r-1,r-1,c-1,max(43,c+len(s)))
        if i==4:
            cv.clear(10,14,3,43)
            cv.put(9,3,'[ carrier found / identify ]',2)
            # A low bitten-off fragment below form, rather than a box enclosing it.
            polygon(cv,[(3,32),(18,32),(22,34),(34,34),(29,36),(5,35)],'metal')
        elif i in (2,5,11,12):
            cv.put(14,3,{2:'carrier / alive',5:'request / pending',11:'machine / engaged',12:'cutting / live'}[i],2)
    cv.clear(5,5,49,65)
    # Footer is quiet type between cut cable ends, no striped uniform header or rectangular menu frame.
    cv.clear(23,23,0,79)
    cv.put(23,3,'AXIS MICRO BBS',7);cv.put(23,22,'/ /',2);cv.put(23,28,'U.G. CNC',8)
    cv.put(23,64,'RUPTURE // %02d'%(i+1),2)
    return cv

def build():
    os.makedirs(OUT,exist_ok=True)
    for i,(name,title,texts,h) in enumerate(MANIFEST):
        cv=splash() if i==0 else inline() if i==1 else functional(i,title,texts)
        g=cv.final()
        assert all(f in PAL and b in PAL and b<=7 for row in g for ch,f,b in row)
        data=B.emit(g,i!=1, '\x1b[24;1H' if i==0 else '' if i==1 else tail(texts))
        open(OUT+'/'+name+'.ans','wb').write(data)
    return {name+'.ans':h for name,_,_,h in MANIFEST}
if __name__=='__main__':print(json.dumps(build(),indent=2))
