"""Strict validation: tokenisation, SGR/CSI whitelist, 25-row viewport emulation (with scrollback),
source-mapped text placement checked AT coordinates, macros at original coords, end-cursor parity,
deterministic rebuild of all 15 outputs, combined-file sequential semantics."""
import re,sys,os,glob,hashlib,json,subprocess
H=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,H);import render,build_pack as B
A=os.path.join(H,'..','ans');SRC='/home/box/agent-data/agents/877144b7-19a7-492b-93e8-970b36b970ed/attachments/'
PHOTO='/workspace/saylor-clockin-2026-11-07.jpg'
def rebuild():
    subprocess.run([sys.executable,os.path.join(H,'build_pack.py')],check=True,capture_output=True)
    subprocess.run([sys.executable,os.path.join(H,'build_poster.py'),PHOTO],check=True,capture_output=True)
    return {os.path.basename(f):hashlib.sha256(open(f,'rb').read()).hexdigest() for f in sorted(glob.glob(A+'/*.ans'))}
h1=rebuild();h2=rebuild()
res={'deterministic_rebuild_all':h1==h2,'output_count':len(h1),'sha256':h1,'files':{}}
MAP={n:h for n,h,_ in B.build()}
def tok(s):
    bad=[];kinds=set();sgr=set();i=0
    for m in re.finditer(r'\x1b',s):
        mm=re.match(r'\x1b\[([0-9;]*)([A-Za-z])',s[m.start():])
        if not mm: bad.append(m.start());continue
        kinds.add(mm.group(2))
        if mm.group(2)=='m': sgr|=set(int(v) for v in mm.group(1).split(';') if v)
    return bad,kinds,sgr
def vis(c): return (' ',0,c[2]) if c[0]==' ' else c
def text_at(g,r,c,t): return ''.join(g[r-1][c-1+i][0] for i in range(len(t)) if c-1+i<80)==t
ALLOW={'full':{'m','H','J'},'inline':{'m'},'combined':{'m','A','B','C'}}
for n,hh in h1.items():
    b=open(os.path.join(A,n),'rb').read();s=b.decode('cp437');r={}
    kind='combined' if n.startswith('15') else 'inline' if n.startswith(('02','14')) else 'full'
    r['kind']=kind;r['cp437_roundtrip']=s.encode('cp437')==b
    r['ctrl_ok']=not [c for c in s if ord(c)<32 and c not in '\x1b\r\n']
    bad,kinds,sgr=tok(s);r['malformed_esc']=len(bad);r['csi']=sorted(kinds);r['csi_whitelist_ok']=kinds<=ALLOW[kind]
    r['sgr_ok']=sgr<=set([0,1]+list(range(30,38))+list(range(40,48)))
    r['ends_with_reset_before_text']= '\x1b[0m' in s
    g,my,cur,w=render.emulate(b,rows=25);sb=render.emulate.scrollback
    r['emu_warn_nonscroll']=[x for x in w if x!='scroll'];r['scrolled_lines']=len(sb)
    r['end_cursor']=[cur[0]+1,cur[1]+1]
    if kind=='full': r['no_scroll_25']=len(sb)==0;r['row25_untouched']=all(c==(' ',7,0) for c in g[24])
    if n in MAP:
        r['source_hash']=MAP[n];ob=open(SRC+MAP[n]+'.ans','rb').read();o=ob.decode('cp437')
        og,omy,ocur,_=render.emulate(ob,rows=40)
        pl=re.findall(r'\x1b\[(\d+);(\d+)H(?:\x1b\[[0-9;]*m)*([^\x1b]+)',o)
        r['source_placements']=[[int(a),int(c),t] for a,c,t in pl]
        r['placements_at_coords']=all(text_at(g,int(a),int(c),t) for a,c,t in pl)
        mac=[(y+1,''.join(ch for ch,_,_ in row).find('%BN')+1) for y,row in enumerate(og) if '%BN' in ''.join(ch for ch,_,_ in row)]
        r['macro_coords_source']=mac
        r['macros_at_source_coords']=all(text_at(g,y,c,'%BN  node %NN') for y,c in mac)
        toks=set(re.findall(r'%[A-Z]{2}|\|\{[A-Z]\}',o));r['macro_tokens']=sorted(toks);r['macro_tokens_present']=all(t in s for t in toks)
        if kind=='full' and pl: r['end_cursor_matches_source']=[ocur[0]+1,ocur[1]+1]==r['end_cursor']
    if n.startswith('14'):
        allrows=sb+g;txt=[''.join(c for c,_,_ in row) for row in allrows]
        r['total_lines']=len([t for t in txt if t.strip()])
        r['footer_name']=any('S A Y L O R   T W I F T' in t for t in txt);r['footer_title']=any('Social Media Marketing' in t for t in txt)
    if n.startswith('15'):
        g5,_,c5,_=render.emulate(open(os.path.join(A,'05_login.ans'),'rb').read(),rows=25)
        off=25-24   # login block occupies viewport rows 2..25 after scrolling
        r['login_block_matches_05_cols1_79']=all(vis(g[y+off][x])==vis(g5[y][x]) for y in range(24) for x in range(79))
        r['fields_relative_ok']=text_at(g,12+off,4,'Handle:   |{P}') and text_at(g,14+off,4,'Password: |{O}') and text_at(g,6+off,51,'%BN  node %NN')
        r['end_cursor_matches_05_shifted']=[cur[0],cur[1]]==[c5[0]+off,c5[1]]
        r['poster_in_scrollback']=any('Social Media Marketing' in ''.join(c for c,_,_ in row) for row in sb+g[:off])
    res['files'][n]=r
print(json.dumps(res,indent=1,ensure_ascii=False))
