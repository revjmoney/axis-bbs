"""Portrait v2: source-aligned limited-palette conversion (no hand-painted features).
Warm ramp 0-8-6-7-15 for skin/hair/room, cool ramp 0-1-9-11-15 for the blue top/denim only,
ordered 4x4 Bayer dither (stable, no FS noise), then per-cell half-block solve with bg<=7."""
import numpy as np
from PIL import Image,ImageEnhance,ImageFilter
PAL=np.array([(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),
     (85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)],float)
BAY=np.array([[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]])/16.0
WARM=[(0,0.0),(8,0.30),(6,0.44),(7,0.70),(15,1.0)]
WARM_B=[(0,0.0),(8,0.33),(7,0.68),(15,1.0)]        # candidate B: neutral grey-cream (less orange)
COOL=[(0,0.0),(1,0.25),(9,0.5),(11,0.78),(15,1.0)]
def ramp_pick(v,ramp,t):
    for (c0,v0),(c1,v1) in zip(ramp,ramp[1:]):
        if v<=v1:
            f=(v-v0)/(v1-v0+1e-6);return c1 if f>t else c0
    return ramp[-1][0]
def convert(path,crop,wcols,warm):
    im=Image.open(path).convert('RGB').crop(crop)
    h=round(im.height*wcols/im.width);h+=h%2
    sm=im.resize((wcols,h),Image.LANCZOS).filter(ImageFilter.UnsharpMask(1,90,1))
    a=np.asarray(sm,float)/255;hsv=np.asarray(sm.convert('HSV'),float)/255
    L=(a@[0.3,0.55,0.15]);L=np.clip((L-0.06)/0.86,0,1)**0.9
    blue=(hsv[...,0]>0.52)&(hsv[...,0]<0.72)&(hsv[...,1]>0.22)
    skin=(hsv[...,0]<0.13)&(hsv[...,1]>0.28)&(L>0.18)
    # source-aligned edge emphasis (Sobel of luminance) -> darker contour lines, no painted features
    gy,gx=np.gradient(L);E=np.hypot(gx,gy);L=np.clip(L-np.clip(E-0.06,0,1)*1.6,0,1)
    # flatten bright wall into near-solid light grey
    L=np.where(L>0.72,0.70+(L-0.72)*0.5,L)
    q=np.zeros((h,wcols),int)
    for y in range(h):
        for x in range(wcols):
            q[y,x]=ramp_pick(L[y,x],COOL if blue[y,x] else (warm if (skin[y,x] or warm is not WARM) else WARM_B),BAY[y%4,x%4])
    cells=[]
    for y in range(0,h,2):
        row=[]
        for x in range(wcols):
            t,b=q[y,x],q[y+1,x]
            if t==b: row.append(('█',t,0) if t else (' ',7,0))
            elif b<=7: row.append(('▀',t,b))
            elif t<=7: row.append(('▄',b,t))
            else:  # both bright: keep brighter one, darken other to its base colour
                row.append(('▀',t,{8:0,9:1,11:3,15:7}[b]))
        cells.append(row)
    return cells
