"""Portrait v3: GrabCut foreground mask (feathered) -> blurred, low-contrast background;
then per-cell optimal CP437 rendering choosing among half-blocks (2 colours, 1x2 px) and
░▒▓ shade mixes (fg/bg blended 25/50/75%) in CIELAB, with light cell-level error diffusion.
Only classic 16 colours (bg 0-7). No painted features, no generation."""
import numpy as np,cv2
PAL=np.array([(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),
     (85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)],float)
def lab(rgb):
    a=np.clip(np.asarray(rgb,np.float32)/255,0,1).reshape(-1,1,3)
    return cv2.cvtColor(a,cv2.COLOR_RGB2LAB).reshape(np.shape(rgb))
# shade glyph coverage measured on the VGA patterns used by render.py
COV={'░':0.25,'▒':0.5,'▓':0.75}
def candidates():
    cand=[]  # (char,fg,bg,top_rgb,bot_rgb)
    for fg in range(16):
        for bg in range(8):
            cand.append(('▀',fg,bg,PAL[fg],PAL[bg]))
            cand.append(('▄',fg,bg,PAL[bg],PAL[fg]))
            if fg!=bg:
                for ch,c in COV.items():
                    m=PAL[fg]*c+PAL[bg]*(1-c);cand.append((ch,fg,bg,m,m))
    return cand
def prepare(path,crop):
    im=cv2.cvtColor(cv2.imread(path),cv2.COLOR_BGR2RGB)
    mask=np.zeros(im.shape[:2],np.uint8);bgd=np.zeros((1,65),np.float64);fgd=np.zeros((1,65),np.float64)
    rect=(130,0,500,1024)            # subject + mug region (source pixel coords)
    cv2.grabCut(im,mask,rect,bgd,fgd,6,cv2.GC_INIT_WITH_RECT)
    fgm=np.where((mask==1)|(mask==3),1.0,0.0).astype(np.float32)
    fgm[585:720,480:630]=1.0   # keep the coffee mug + hand sharp (source coords)
    fgm=cv2.morphologyEx(fgm,cv2.MORPH_CLOSE,np.ones((15,15),np.uint8))
    fgm=cv2.GaussianBlur(fgm,(0,0),9)                       # feathered edge
    bgimg=cv2.GaussianBlur(im,(0,0),22).astype(np.float32)
    g=bgimg.mean(2,keepdims=True);bgimg=(g+(bgimg-g)*0.45)*0.78+20   # desaturate, lower contrast, dim
    fgimg=im.astype(np.float32)
    fgimg=np.clip(fgimg*1.6-cv2.GaussianBlur(fgimg,(0,0),5)*0.6,0,255)   # unsharp: keep eyes/smile structure
    g=fgimg.mean(2,keepdims=True);fgimg=g+(fgimg-g)*0.85              # restrained colour
    out=fgimg*fgm[...,None]+bgimg*(1-fgm[...,None])
    x0,y0,x1,y1=crop
    return np.clip(out[y0:y1,x0:x1],0,255).astype(np.uint8),fgm[y0:y1,x0:x1]
def convert(path,crop,wcols,diff=0.35,hb_bias=0.0):
    img,m=prepare(path,crop)
    h=round(img.shape[0]*wcols/img.shape[1]);h+=h%2
    sm=cv2.resize(img,(wcols,h),interpolation=cv2.INTER_AREA).astype(np.float32)
    C=candidates();ISHB=np.array([c[0] in '▀▄' for c in C]);CT=lab(np.array([c[3] for c in C]));CB=lab(np.array([c[4] for c in C]))
    work=sm.copy();cells=[]
    for y in range(0,h,2):
        row=[]
        for x in range(wcols):
            t=lab(np.clip(work[y,x],0,255)[None])[0];b=lab(np.clip(work[y+1,x],0,255)[None])[0]
            e=((CT-t)**2).sum(1)+((CB-b)**2).sum(1)
            if hb_bias: e=e*np.where(ISHB,1.0-hb_bias,1.0)
            # tiny bias toward half-blocks for detail where top/bottom differ strongly
            k=int(np.argmin(e));ch,fg,bg,tr,br=C[k]
            for yy,rr in ((y,tr),(y+1,br)):
                err=(work[yy,x]-rr)*diff
                if x+1<wcols: work[yy,x+1]+=err*0.5
                if yy+2<h: work[yy+2,x]+=err*0.3
                if yy+2<h and x>0: work[yy+2,x-1]+=err*0.2
            if ch in '▀▄' and fg==bg: ch='█'
            if ch=='█' and fg==0: ch=' '
            row.append((ch,fg,bg))
        cells.append(row)
    return cells
