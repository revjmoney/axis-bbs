# Axis Micro BBS: underground ANSI pack (2026-11-07, rev 4: poster nameplate)

Original art in a heavy-ANSI underground BBS *style*, with no group or artist affiliation or signature. Uploads were left untouched.

## Format
- 80 columns, CP437 bytes, classic 16-colour SGR only (0, 1, 30-37, 40-47). No iCE colour, blink, truecolor or Unicode. No SAUCE record.
- Full screens (01, 03-13): `ESC[0m ESC[2J ESC[H`, then every row drawn with `ESC[row;1H`. Row 24 stops at column 79; row 25 is never touched (validated: no scroll on a 25-row viewport).
- 02 logo banner: 12 inline rows of 79 columns separated by CRLF, with no cursor moves or clear (like the original).
- 14 poster (v4): 91 inline rows (79 columns, CRLF). It scrolls on purpose and uses SGR only. A single ornamental strip is at the top, with no name there. One framed nameplate at the bottom reads `Saylor Twift`, with `Social Media Marketing` directly underneath.

## Recommended login ordering (firmware-independent)
1. Send `14_saylor_clockin_poster_tall.ans`.
2. The host waits for a keypress. That pause is firmware logic: ANSI cannot pause by itself, and this pack does not fake one.
3. Send `05_login.ans` (absolute coordinates, unchanged semantics).

`15_login_with_saylor_poster_scroll.ans` is a single-file convenience variant: the poster, then the login printed inline (24 rows x 79 columns). %BN/%NN and the Handle/Password fields are placed with relative CUU/CUD/CR/CUF moves only, with no `ESC[H` or `ESC[2J`. In a 25-line scrolling emulation, the login block ends at viewport rows 2-25 and matches 05 cell-for-cell (columns 1-79), and the cursor ends right after `|{O}`. Column 80 is blank in this variant. There is no pause, so the poster scrolls into scrollback immediately. Nothing was integrated or tested on the live BBS.

## Mapping (new file <- uploaded source sha256 filename)
- `01_splash_fullscreen.ans` <- `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f`
- `02_logo_banner_inline.ans` <- `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34`
- `03_axis_welcome.ans` <- `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4`
- `04_axis_main_menu.ans` <- `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78`
- `05_login.ans` <- `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f`
- `06_apply_new_user.ans` <- `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e`
- `07_doors_menu.ans` <- `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc`
- `08_messages_menu.ans` <- `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d`
- `09_files_menu.ans` <- `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678`
- `10_matrix_menu.ans` <- `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84`
- `11_fast_menu.ans` <- `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264`
- `12_shop_screen.ans` <- `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1`
- `13_mill_screen.ans` <- `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855`
- `14_saylor_clockin_poster_tall.ans` <- `new: from /workspace/saylor-clockin-2026-11-07.jpg (sha256 65a6f53ea252c35e65c91ea283bffaa65152f0c31003275cde2f20a07fec232d); photo not bundled`
- `15_login_with_saylor_poster_scroll.ans` <- `new: from /workspace/saylor-clockin-2026-11-07.jpg (sha256 65a6f53ea252c35e65c91ea283bffaa65152f0c31003275cde2f20a07fec232d); photo not bundled`

## Preserved semantics
- `%BN  node %NN` is at row 6, column 51, the same coordinate as every original. It is written after the art, so a longer expansion overwrites art rather than shifting it.
- Every source `ESC[r;cH` text placement is reproduced and verified at that exact cell, in the original order. End cursors match the originals; on login the cursor ends right after `|{O}`.
- Menu screens (04, 07-11): a black window at rows 9-21, columns 4-44, holds the firmware-drawn list; the prompt stays on row 22. Art fills columns 46-78. **Assumption:** the firmware was not inspected, so menus wider than 41 columns or below row 21 would overlap the art.
- Fixed-text screens (03, 05, 06, 12, 13): a bevelled black text plate protects the known text (and about 26 columns of input after the login fields); the rest of the body is illustrated.

## Art notes
- Layered half-block pixel art: cylindrical-ramp pipes with flange highlights, circuit traces, a sculpted gear (cast-shadow layer, black outline, rim bevel lit from the top-left, recessed web, bolt holes, hub), and per-screen icons drawn through a shadow + outline + face stack.
- Poster (v3): the exact source photo (unchanged). An OpenCV GrabCut foreground mask (with the mug/hand region forced to foreground) is feathered, and the background is Gaussian-blurred, desaturated, dimmed and lowered in contrast. The foreground is lightly sharpened and slightly desaturated. Crop x 150-620 at full height, scaled to 78 columns with square half-block pixels (no stretching). Each cell picks the best of: half-blocks (2 colours) or ░▒▓ fg/bg mixes at 25/50/75% (gives tan/cream midtones), scored in CIELAB, with light cell-level error diffusion and no ordered dither grid. Classic 16 colours only. No painted features, no image generation. The v3 candidate was selected after visual comparison of four crop and bias variants (rejected candidates not bundled).

## Limitations
- Validated only in the bundled emulator (render.py), not on a live BBS, telnet client or CYD.
- Preview text glyphs use Terminus TTF (an IBM VGA font download was blocked); blocks, shades and box lines are drawn on an exact 8x16 grid.
- At 78 columns the face is about 22 columns wide: eyes and smile read but stay soft; shade-glyph texture is visible up close; the mug is still faint. Not photorealistic.
- Rebuild of 14/15 needs opencv-python-headless (installed on the box with pip --user).

## Rebuild and validate
`python3 src/build_pack.py && python3 src/build_poster.py /workspace/saylor-clockin-2026-11-07.jpg && python3 src/validate.py > validation.json` (requires Pillow and numpy; output is deterministic).
