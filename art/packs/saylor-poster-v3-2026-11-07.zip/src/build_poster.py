#!/usr/bin/env python3
"""Tall scrolling 80-col poster: photo -> half-block CP437 portrait (each cell = 1x2 square px on VGA 8x16),
best (fg,bg,char) per cell search under the 16fg/8bg constraint, plus layered frame + nameplate."""
import sys,os,numpy as np
from PIL import Image,ImageEnhance,ImageFilter
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
PAL=np.array([(0,0,0),(0,0,170),(0,170,0),(0,170,170),(170,0,0),(170,0,170),(170,85,0),(170,170,170),
     (85,85,85),(85,85,255),(85,255,85),(85,255,255),(255,85,85),(255,85,255),(255,255,85),(255,255,255)],float)
def portrait(path,wcols=74):
    im=Image.open(path).convert('RGB').crop((110,0,640,1024))  # subject crop, aspect kept
    im=ImageEnhance.Contrast(im).enhance(1.25);im=ImageEnhance.Color(im).enhance(1.35)
    im=ImageEnhance.Brightness(im).enhance(1.12);im=im.filter(ImageFilter.UnsharpMask(2,120,2))
    h=round(im.height*wcols/im.width); h+=h%2
    a=np.asarray(im.resize((wcols,h),Image.LANCZOS),float).copy()
    # manual artist refinement: re-assert facial features lost at 74px width (source-measured spots)
    k=wcols/530.0
    def P(x,y,c):
        X,Y=int(round((x-110)*k)),int(round(y*k))
        if 0<=X<wcols and 0<=Y<h: a[Y,X]=c
    for ex,ey in ((312,158),(382,135)):            # eyes: dark iris + light glint, brow above
        P(ex-7,ey,(20,10,5));P(ex,ey,(25,15,5));P(ex+7,ey,(230,230,230))
        for d in (-8,0,8): P(ex+d,ey-16,(15,8,5))
    for d in range(-21,22,7): P(370+d,212+abs(d)//4,(255,255,255))   # smile / teeth
    P(349,214,(200,40,40));P(392,205,(200,40,40))
    P(268,255,(255,255,85))                         # hoop earring glint
    # perceptual-ish weighting
    w=np.array([0.35,0.45,0.2])
    def err(px,c): return (((px[...,None,:]-PAL[c][None,:,:])**2)*w).sum(-1)
    cells=[]
    for y in range(0,h,2):
        row=[]
        for x in range(wcols):
            t,b=a[y,x],a[y+1,x]
            et=(((t-PAL)**2)*w).sum(1); eb=(((b-PAL)**2)*w).sum(1)
            best=None
            for fg in range(16):
                for bg in range(8):
                    e1=et[fg]+eb[bg]; e2=et[bg]+eb[fg]
                    if best is None or e1<best[0]: best=(e1,'▀',fg,bg)
                    if e2<best[0]: best=(e2,'▄',fg,bg)
            _,ch,fg,bg=best
            ct,cb=(fg,bg) if ch=='▀' else (bg,fg)
            for yy,c in ((y,ct),(y+1,cb)):
                e=(a[yy,x]-PAL[c])*0.35   # damped Floyd-Steinberg diffusion
                if x+1<wcols: a[yy,x+1]+=e*7/16
                if yy+1<h:
                    if x>0: a[yy+1,x-1]+=e*3/16
                    a[yy+1,x]+=e*5/16
                    if x+1<wcols: a[yy+1,x+1]+=e/16
            if fg==bg or (ch=='▀' and fg==bg): ch=' ' if fg==0 else '█'
            if ch=='█': bg=0
            row.append((ch,fg,bg))
        cells.append(row)
    return cells
def frame_rows(n,th):
    return [[None]*80 for _ in range(n)]
def poster(path):
    import portrait3 as P3
    th=B.THEMES['violet'];P=P3.convert(path,(150,0,620,1024),78,hb_bias=0.15);H=len(P)  # v3 candidate C (selected by visual review)
    # header: layered SAYLOR logo plate
    cv=B.Canvas(6,B.plate_tex(th,3));B.logo(cv,'SAYLOR',3,1,th,slant=False);B.ramp_bar(cv,5,th)
    rows=cv.final()
    for i,pr in enumerate(P):
        r=[]
        k=i%5
        L=[('▐',th['acc'],0)] if k else [('█',6,0)]
        R=[('▌',th['acc'],0)] if k else [('█',6,0)]
        r=L+pr+R; r=r[:80]
        while len(r)<80: r.append(('░',5,0))
        rows.append(r)
    ft=B.Canvas(8,B.plate_tex(th,9));B.ramp_bar(ft,0,th)
    B.logo(ft,'TWIFT',14,3,th,slant=False)
    for y in (6,7):
        for x in range(80): ft.put(y,x,' ',7)
    ft.put(6,22,'▐ S A Y L O R   T W I F T ▌',15,0);ft.put(6,22,'▐',13);ft.put(6,48,'▌',13)
    ft.put(7,20,'░▒▓ ',5);ft.put(7,24,'Social Media Marketing',14);ft.put(7,46,' ▓▒░',5)
    rows+=ft.final()
    return rows
def inline_login(g05):
    """Sequential (scroll-safe) login: 24 rows printed inline (79 cols, CRLF), then fields placed with
    RELATIVE moves only (CUU/CUD/CR/CUF) so it works after any amount of scrollback; no ESC[H / ESC[2J."""
    out=B.emit(g05,False)       # rows 1..24, cursor ends on row 24 of the block
    rel='\x1b[18A\r\x1b[50C\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;33mod\x1b[0;1;30me \x1b[0;1;37m%NN'
    rel+='\x1b[6B\r\x1b[3C\x1b[0;37mHandle:   |{P}\x1b[2B\r\x1b[3C\x1b[0;37mPassword: |{O}'
    return out+rel.encode('cp437')
if __name__=='__main__':
    src=sys.argv[1];out=B.OUT
    rows=poster(src)
    data=B.emit(rows,False)+b'\r\n'
    open(os.path.join(out,'14_saylor_clockin_poster_tall.ans'),'wb').write(data)
    g05=B.login_grid()
    open(os.path.join(out,'15_login_with_saylor_poster_scroll.ans'),'wb').write(data+inline_login(g05))
    print(len(rows),'rows')
