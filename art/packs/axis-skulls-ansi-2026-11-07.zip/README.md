# Axis Micro BBS: SKULLS alternative screen set (2026-11-07)

A separate art direction from the steel/gear pack, which was left byte-identical. Original art in an underground-BBS style; no group or artist affiliation.

- Palette: black, dark red, red, grey, charcoal and bone white only (VGA 0/4/12/7/8/15; SGR 0,1,30,31,37,40,41,47). Validated per cell.
- Negative space: black voids form the eye sockets, nasal cavity, teeth gaps, cheek hollows, cranial fractures and the menu window; the half-skull on login is cropped by the screen edge. Layers: red cast shadow, then black outline, then a sculpted face lit from the top-left with a red rim light.
- Format, coordinates and semantics are the same as the main pack: 80 columns, CP437, `ESC[2J ESC[H` plus per-row `ESC[r;1H` (row 24 stops at column 79); 02 is 12 inline rows. `%BN  node %NN` is at row 6, column 51. Source text placements (12;4, 14;4, 22;4) are written last, in the original order; the cursor ends where the originals left it (after `|{O}` on login).
- Menu window (assumption; the firmware was not inspected): rows 9-21, columns 4-44 are kept black and validated blank. Wider menus would overlap the art.
- Not tested on a live BBS; local emulator only. Preview text glyphs use the Terminus font.

## Mapping (file <- uploaded source sha256 filename)
- `01_skull_splash_fullscreen.ans` <- `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f`
- `02_skull_logo_banner_inline.ans` <- `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34`
- `03_skull_axis_welcome.ans` <- `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4`
- `04_skull_axis_main_menu.ans` <- `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78`
- `05_skull_login.ans` <- `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f`
- `06_skull_apply_new_user.ans` <- `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e`
- `07_skull_doors_menu.ans` <- `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc`
- `08_skull_messages_menu.ans` <- `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d`
- `09_skull_files_menu.ans` <- `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678`
- `10_skull_matrix_menu.ans` <- `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84`
- `11_skull_fast_menu.ans` <- `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264`
- `12_skull_shop_screen.ans` <- `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1`
- `13_skull_mill_screen.ans` <- `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855`

Rebuild: `python3 src/build_skulls.py && python3 src/validate_skulls.py > validation.json` (deterministic; uses Pillow). `src/build_pack.py` is a copied helper module (font, canvas, emitter).
