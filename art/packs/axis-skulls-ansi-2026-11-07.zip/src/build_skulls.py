#!/usr/bin/env python3
"""Axis Micro BBS - SKULLS alternative set. Red / black / grey / bone only (VGA 0,4,7,8,12,15).
Negative space is compositional: black voids carve eye sockets, nasal cavity, teeth gaps, cheek hollows,
the menu window and fractures. Shared low-level helpers (Canvas, logo font, emit) from build_pack.py."""
import math,os,random,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
W=80;OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')
TH=dict(r=[15,7,15,7,12,4,8,0],acc=12,warm=12,t1=4,t2=4)
ALLOWED={0,4,7,8,12,15}

def smoke(seed,y0=0):
    """Charcoal smoke stains + rare ember dots over black: texture that keeps black dominant."""
    def f(x,y):
        v=math.sin(x*0.21+y*0.9+seed)+math.sin(x*0.07-y*0.35+seed*2)+0.6*math.sin((x+y)*0.5)
        if (x*29+y*31+seed)%151==0: return ('·',12,0)
        if v>1.9: return ('▒',8,0)
        if v>1.45: return ('░',8,0)
        if v<-2.0: return ('░',4,0)
        return (' ',7,0)
    return f

def skull(cv,cx,cy,s,seed=0,jaw_open=0.0,glint=True,crack=True,shade_side=1):
    """Sculpted skull on the half-row pixel grid (square px). s = cranium radius in px."""
    rnd=random.Random(seed);P={}
    def cran(dx,dy): return (dx/s)**2+((dy)/(s*0.92))**2<1
    def jaw(dx,dy): return (s*0.35<dy<s*(1.18+jaw_open)) and abs(dx)<s*(0.62-0.25*max(0,(dy-s*0.75)/(s*0.45)))
    def cheek(dx,dy): return (s*0.25<dy<s*0.75) and abs(dx)<s*0.86-(dy-s*0.25)*0.5
    def eye(dx,dy): return ((abs(dx)-s*0.40)/(s*0.27))**2+((dy-s*0.20)/(s*0.24))**2<1
    def nose(dx,dy): return s*0.48<dy<s*0.72 and abs(dx)<(dy-s*0.48)*0.55+0.6
    def mouth_gap(dx,dy): return jaw_open>0 and s*0.98<dy<s*(0.98+jaw_open)
    for hy in range(int(cy-s-3),int(cy+s*(1.25+jaw_open)+4)):
        for x in range(int(cx-s-3),int(cx+s+4)):
            dx=x-cx;dy=hy-cy
            if not (cran(dx,dy) or jaw(dx,dy) or cheek(dx,dy)): continue
            # light from top-left: pseudo-normal from cranium ellipse
            nx=dx/s;ny=dy/(s*0.92);L=-(nx*0.65+ny*0.55)*shade_side if shade_side>0 else -(-nx*0.65+ny*0.55)
            c=15 if L>0.35 else 7 if L>-0.2 else 8
            if nx*shade_side>0.62: c=12 if nx*shade_side<0.8 else 4          # red rim light (restrained)
            if eye(dx,dy) or nose(dx,dy) or mouth_gap(dx,dy): c=0             # negative-space voids
            elif ((abs(dx)-s*0.40)/(s*0.34))**2+((dy-s*0.20)/(s*0.31))**2<1: c=8 if c!=4 else 4   # socket bevel
            elif s*0.5<dy<s*0.82 and s*0.45<abs(dx)<s*0.75: c=8              # cheek hollows
            if s*0.84<dy-(jaw_open*s if dy>s*0.98 else 0)<s*1.08 and abs(dx)<s*0.5:   # teeth
                c=0 if (dx%3==0 or abs(dy-(s*0.98+(jaw_open*s if dy>s*0.98 else 0)))<0.6) else (15 if dx<0 else 7)
            P[(hy,x)]=c
    if crack:   # fracture: jagged black path from crown
        x=cx+rnd.randint(-s//3,s//3);hy=int(cy-s*0.9)
        for _ in range(int(s*0.7)):
            if (hy,x) in P: P[(hy,x)]=0
            if (hy,x+1) in P and rnd.random()<0.4: P[(hy,x+1)]=8
            hy+=1;x+=rnd.choice((-1,0,1))
    # layers: red cast shadow, black outline, face
    for (hy,x) in P: cv.p(hy+2,x+2*shade_side,4)
    for (hy,x) in P:
        for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
            if (hy+oy,x+ox) not in P: cv.p(hy+oy,x+ox,0)
    for (hy,x),c in P.items():
        cv.p(hy,x,c)
    if glint:
        for sx in (-1,1):
            cv.p(int(cy+s*0.22),int(cx+sx*s*0.40),12)
    return P
def bone(cv,x0,y0,x1,y1,w=2):
    n=max(abs(x1-x0),abs(y1-y0))
    for i in range(n+1):
        x=x0+(x1-x0)*i/n;y=y0+(y1-y0)*i/n
        for k in range(-w//2,w-w//2): cv.p(int(y)+k,int(x),15 if k<0 else 7)
    for (x,y) in ((x0,y0),(x1,y1)):
        for oy in range(-2,3):
            for ox in range(-2,3):
                if ox*ox+oy*oy<=5: cv.p(int(y)+oy,int(x)+ox,15 if oy<0 else 7 if oy<2 else 8)
def drip_edge(cv,y0,y1,x0,x1,seed):
    """Window carved as negative space: charcoal/red dripping lip around the black void (outside it)."""
    rnd=random.Random(seed)
    for x in range(x0-1,x1+2):
        cv.put(y0-1,x,'▄',8);
        if rnd.random()<0.3: cv.put(y0-1,x,'▄',4)
    for x in range(x0-1,x1+2): cv.put(y1+1,x,'▀',8)
    for y in range(y0,y1+1): cv.put(y,x0-1,'▐',8);cv.put(y,x1+1,'▌',8 if (y+seed)%5 else 4)
def header(cv,title,seed):
    end=B.logo(cv,title.upper(),3,0,TH,slant=False)
    for x in range(W): cv.put(5,x,' ',7)
    cv.put(5,1,'▄▀▄ ',4);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',4)
    for x in range(W): cv.put(6,x,'▀',[8,8,4,8,0,8,12,8][(x*3+seed)%8],0)
    return end
def mini_skull_header(cv,end):
    if end<64: skull(cv,73,5,4,seed=end,crack=False,glint=True)

def screen(idx,title,comp,texts,menu):
    seed=idx*7;cv=B.Canvas(24,smoke(seed))
    end=header(cv,title,seed);mini_skull_header(cv,end)
    comp(cv,seed)
    if menu:
        cv.clear(8,20,3,43);drip_edge(cv,8,20,3,43,seed);cv.clear(21,21,3,43)
    else:
        rows=[r for r,_,_,_ in texts];w=max(len(t) for *_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        cv.clear(min(rows)-1,max(rows)-1,3,3+w);drip_edge(cv,min(rows)-1,max(rows)-1,3,3+w,seed)
    for x in range(W): cv.put(23,x,' ',7)
    for x in range(W):
        cv.put(22,x,'▄',8 if (x+seed)%7 else 4) if cv.cell[22][x] is None and not (menu is False and False) else None
    cv.put(23,3,'▀▄▀',4);cv.put(23,22,'A X I S   M I C R O   B B S',7);cv.put(23,52,'u.g. cnc',8);cv.put(23,76,'▀▄▀',4)
    cv.clear(21,21,3,50) if menu else None
    return cv
# --------------- compositions (distinct per screen) ----------------
def c_crossbones(cx,cy,s):
    def f(cv,seed):
        bone(cv,cx-s-6,cy-s,cx+s+6,cy+s*2,3);bone(cv,cx+s+6,cy-s,cx-s-6,cy+s*2,3);skull(cv,cx,cy,s,seed)
    return f
def c_halfskull(cv,seed): skull(cv,74,22,15,seed,shade_side=1)          # cropped by right edge: negative space
def c_twins(cv,seed): skull(cv,70,30,8,seed+1,shade_side=-1);skull(cv,56,24,10,seed)
def c_arch(cv,seed):
    for hy in range(16,44):
        for x in range(50,78):
            dx=(x-64)/13.0;dy=(hy-30)/14.0
            r=dx*dx+(min(0,dy))**2
            if r<1 and not r<0.55: cv.p(hy,x,[7,8,8,4][(hy//2+x)%4])
    skull(cv,64,30,7,seed)
def c_pile(cv,seed):
    for i,(x,y,s) in enumerate(((56,37,6),(70,37,6),(63,26,7))): skull(cv,x,y,s,seed+i,crack=i==2,shade_side=1 if i%2==0 else -1)
def c_bones(cv,seed):
    for i in range(5): bone(cv,48+i*6,42,54+i*5,34-i,2)
    skull(cv,64,24,8,seed,jaw_open=0.2)
def c_grid(cv,seed):
    for i in range(3):
        for j in range(3): skull(cv,53+j*10,18+i*10,4,seed+i*3+j,crack=False,glint=(i+j)%2==0)
def c_streak(cv,seed):
    for k in range(9):
        y=18+k*3
        for x in range(46,60+k*2): cv.p(y,x,4 if x<54 else 12 if k%2 else 8)
    skull(cv,66,28,9,seed,shade_side=1)
def c_big(cx,cy,s,jaw=0.0,side=1):
    def f(cv,seed): skull(cv,cx,cy,s,seed,jaw_open=jaw,shade_side=side)
    return f
P22='arrows move, Enter picks, or press the key'
SCREENS=[
 ('03_skull_axis_welcome','axis',c_crossbones(60,28,9),[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_skull_axis_main_menu','axis',c_crossbones(63,26,7),[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_skull_login','login',c_halfskull,[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_skull_apply_new_user','apply',c_twins,[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_skull_doors_menu','doors',c_arch,[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_skull_messages_menu','msgs',c_pile,[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_skull_files_menu','files',c_bones,[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_skull_matrix_menu','matrix',c_grid,[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_skull_fast_menu','fast',c_streak,[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_skull_shop_screen','shop',c_big(62,28,11,0.0,1),[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_skull_mill_screen','mill',c_big(62,26,10,0.35,-1),[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;31mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for (r,c,fg,s) in texts: t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',B.V2A[fg&7],s)
    return t
def check_palette(g):
    for row in g:
        for ch,fg,bg in row: assert fg in ALLOWED|{0} and bg in {0,4,7}, (ch,fg,bg)
def build():
    os.makedirs(OUT,exist_ok=True);man=[]
    # splash: AXIS over a giant skull that dissolves into black (negative space), red rim light
    cv=B.Canvas(24,smoke(3))
    skull(cv,40,22,15,seed=11,jaw_open=0.12)
    B.logo(cv,'AXIS',8,1,TH,sx=3,sy=2)
    cv.clear(22,23,0,79)
    cv.put(22,26,'Axis Micro BBS Firmware',15);cv.put(23,22,'▐ U N D E R G R O U N D   C N C ▌',15,4)
    g=cv.final();check_palette(g)
    open(os.path.join(OUT,'01_skull_splash_fullscreen.ans'),'wb').write(B.emit(g,True,'\x1b[24;1H'))
    man.append(('01_skull_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'))
    cv=B.Canvas(12,smoke(5))
    skull(cv,9,10,6,seed=2,shade_side=1);skull(cv,70,10,6,seed=3,shade_side=-1)
    B.logo(cv,'AXIS',17,1,TH,sx=2,sy=2)
    cv.clear(11,11,0,79);cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',15,4)
    g=cv.final();check_palette(g)
    open(os.path.join(OUT,'02_skull_logo_banner_inline.ans'),'wb').write(B.emit(g,False))
    man.append(('02_skull_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'))
    for i,(name,title,comp,texts,h) in enumerate(SCREENS):
        cv=screen(i,title,comp,texts,texts[0][0]==22);g=cv.final();check_palette(g)
        open(os.path.join(OUT,name+'.ans'),'wb').write(B.emit(g,True,tail(texts)));man.append((name+'.ans',h))
    return man
if __name__=='__main__':
    for m in build(): print(*m)
