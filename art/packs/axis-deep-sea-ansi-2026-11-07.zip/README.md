# Axis Micro BBS: DEEP-SEA BIOMECHANICAL alternative set (2026-11-07)

Theme 2 of 4. Original underground-style art; no group or artist affiliation. Earlier packs are untouched.

- Palette: black, navy, light blue, teal, cyan, charcoal, silver and bone only (VGA 0/1/9/3/11/8/7/15). Validated per cell.
- Hero: a biomechanical anglerfish with a ribbed silver/bone hull lit from above, a black negative-space mouth with bone teeth, black gill slits, a cyan eye, and a jointed lure stalk ending in a stepped bioluminescent bulb (cyan/teal/navy halo).
- Environment: navy haze fading to black for the vertical descent, drifting marine snow, kelp/tendril silhouettes with teal tips, and bubble trails. Sprites use layers: navy cast shadow, then black outline, then the face.
- Per screen: splash and welcome = anglerfish; main menu = smaller anglerfish; login = riveted porthole with an eye peering in; apply = diving helmet; doors = pressure hatch with wheel; msgs = sonar arcs + ribcage; files = salvage canister with glowing core; matrix = a 2x2 porthole array; fast = jellyfish with negative-space cores; shop = submersible with lit portholes; mill = large anglerfish.
- Semantics are the same as the other sets: 80 columns, CP437, `ESC[2J ESC[H` plus per-row `ESC[r;1H` (row 24 stops at column 79); 02 is 12 inline rows. `%BN  node %NN` is at row 6, column 51. Source placements (12;4, 14;4, 22;4) are written last, in order; end cursors match the originals.
- Menu window (assumption; firmware not inspected): rows 9-21, columns 4-44 are black and validated blank. Wider menus would overlap the art.
- Local emulator only; not tested on a live BBS. Preview text glyphs use the Terminus font.

## Mapping (file <- uploaded source sha256 filename)
- `01_sea_splash_fullscreen.ans` <- `5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f`
- `02_sea_logo_banner_inline.ans` <- `d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34`
- `03_sea_axis_welcome.ans` <- `cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4`
- `04_sea_axis_main_menu.ans` <- `f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78`
- `05_sea_login.ans` <- `71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f`
- `06_sea_apply_new_user.ans` <- `0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e`
- `07_sea_doors_menu.ans` <- `a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc`
- `08_sea_messages_menu.ans` <- `c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d`
- `09_sea_files_menu.ans` <- `2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678`
- `10_sea_matrix_menu.ans` <- `b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84`
- `11_sea_fast_menu.ans` <- `3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264`
- `12_sea_shop_screen.ans` <- `3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1`
- `13_sea_mill_screen.ans` <- `f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855`

Rebuild: `python3 src/build_sea.py && python3 src/validate_sea.py > validation.json && python3 src/sheet.py` (deterministic; Pillow; reuses helpers from build_pack.py/build_crt.py).
