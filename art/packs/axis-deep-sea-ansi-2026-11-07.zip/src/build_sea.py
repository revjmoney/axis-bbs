#!/usr/bin/env python3
"""Axis Micro BBS - DEEP-SEA BIOMECHANICAL alternative set.
Palette: black, navy, light blue, teal, cyan, charcoal, silver, bone (VGA 0,1,9,3,11,8,7,15)."""
import math,os,random,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
import build_pack as B
from build_crt import bezel_window,rrect
W=80;OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','ans')
TH=dict(r=[15,7,11,3,9,1,8,0],acc=11,warm=15,t1=1,t2=1)
ALLOWED={0,1,9,3,11,8,7,15}
def depth(seed):
    """Vertical descent: navy water haze near the top fading into black, drifting marine snow."""
    def f(x,y):
        h=(x*73856093^y*19349663^seed*83492791)&1023
        if h<5: return ('·',9,0)
        if h<9: return ('·',8,0)
        if y<10 and (x+y*3+seed)%7<(10-y)//3: return ('░',1,0)
        if 10<=y<14 and (x*5+y+seed)%13==0: return ('░',1,0)
        return (' ',7,0)
    return f
class L:   # layered sprite builder: collects pixels then draws shadow, outline, face
    def __init__(s): s.P={}
    def p(s,y,x,c): s.P[(int(y),int(x))]=c
    def draw(s,cv,shadow=1):
        for (y,x) in s.P: cv.p(y+2,x+2,shadow)
        for (y,x) in s.P:
            for oy,ox in ((-1,0),(1,0),(0,-1),(0,1)):
                if (y+oy,x+ox) not in s.P: cv.p(y+oy,x+ox,0)
        for (y,x),c in s.P.items(): cv.p(y,x,c)
def glow(cv,cx,cy,r):
    """Stepped bioluminescent halo drawn into empty water only."""
    for y in range(int(cy-r),int(cy+r)+1):
        for x in range(int(cx-r),int(cx+r)+1):
            d=math.hypot(x-cx,y-cy)
            if d<r and 0<=y<cv.R*2 and 0<=x<80 and cv.px[y][x] is None:
                cv.p(y,x,1 if d>r*0.6 else 3 if d>r*0.3 else 11)
    cv.p(int(cy),int(cx),15)
def tendril(cv,x0,y0,length,amp,phase,dirx=1,diry=1,col=8,tip=3):
    for t in range(length):
        x=x0+dirx*t*0.6+amp*math.sin(t*0.25+phase);y=y0+diry*t
        cv.p(int(y),int(x),col);cv.p(int(y),int(x)+1,1)
    cv.p(int(y),int(x),tip)
def bubbles(cv,x,y0,n,seed):
    r=random.Random(seed)
    for i in range(n):
        yy=y0-i*r.randint(3,5);xx=x+r.randint(-2,2)
        if r.random()<0.5: cv.p(yy,xx,9);cv.p(yy-1,xx,11)
        else: cv.p(yy,xx,11)
def angler(cv,cx,cy,s,facing=-1,seed=0,lure=True,mouth=0.55):
    """Biomechanical anglerfish: ribbed silver/bone hull, black mouth void with bone teeth, gill slits,
    cyan eye, lit lure on a jointed stalk. s = body half-height in px. facing -1 = faces left."""
    S=L();f=facing
    for y in range(int(cy-s),int(cy+s)+1):
        for x in range(int(cx-s*1.6),int(cx+s*1.6)+1):
            dx=(x-cx)*f;dy=y-cy
            body=(dx/(s*1.45))**2+(dy/s)**2<1
            tail=dx>s*1.1 and abs(dy)<(dx-s*1.1)*0.9 and dx<s*1.6
            if not(body or tail): continue
            ny=dy/s;nx=dx/(s*1.45)
            Lv=-(ny*0.8)+(-nx*0.2)
            c=15 if Lv>0.45 else 7 if Lv>0.0 else 8 if Lv>-0.5 else 1
            if body and int(dx)%4==0 and dx>-s*0.6: c=8 if c!=1 else 0          # mechanical ribs
            if body and int(dx)%4==1 and dx>-s*0.6 and c==7: c=15
            if tail and int(dy+dx)%3==0: c=3
            # mouth: wedge from the front, black negative space
            if dx<-s*0.35 and abs(dy-s*0.15)<(-dx-s*0.35)*mouth: c=0
            S.p(y,x,c)
    # teeth: bone spikes along the mouth edges (inside void)
    for k in range(7):
        tx=cx+f*(-s*0.45-k*s*0.15);ty_up=cy+s*0.15-(s*0.10+k*s*0.15*mouth)
        ty_dn=cy+s*0.15+(s*0.10+k*s*0.15*mouth)
        for t in range(2+(k%2)):
            S.p(ty_up+t,tx,15);S.p(ty_dn-t,tx,7)
    # gills: negative-space slits
    for g in range(3):
        for t in range(int(s*0.6)): S.p(cy-s*0.3+t,cx+f*(s*0.1+g*2)+((t//3) if f>0 else -(t//3))*0,0)
    # eye
    ex,ey=cx-f*s*0.35,cy-s*0.45
    for y in range(int(ey-2),int(ey+3)):
        for x in range(int(ex-2),int(ex+3)):
            d=math.hypot(x-ex,y-ey)
            if d<2.6: S.p(y,x,11 if d>1.4 else 0)
    S.p(ey-1,ex-1,15)
    S.draw(cv)
    if lure:   # jointed stalk + glowing bulb
        x0,y0=cx-f*s*0.2,cy-s*0.95;bx,by=cx-f*s*1.55,cy-s*1.35
        for t in range(21):
            u=t/20;x=x0+(bx-x0)*u;y=y0+(by-y0)*u-math.sin(u*math.pi)*s*0.5
            cv.p(int(y),int(x),7 if t%4 else 15)
        glow(cv,bx,by+2,5)
def porthole(cv,cx,cy,r,inner=None,seed=0):
    S=L()
    for y in range(int(cy-r),int(cy+r)+1):
        for x in range(int(cx-r),int(cx+r)+1):
            d=math.hypot(x-cx,y-cy)
            if d>r: continue
            a=math.atan2(y-cy,x-cx);lit=-math.cos(a+0.8)
            if d>r*0.78:
                c=15 if lit>0.5 else 7 if lit>-0.2 else 8
                if abs(d-r*0.89)<0.6 and int(math.degrees(a)+360)%45<8: c=0  # rivets
            else:
                c=1 if d>r*0.55 else 0
                if -r*0.6<x-cx+y-cy<-r*0.45 and d<r*0.7: c=9        # glass glint
            S.p(y,x,c)
    S.draw(cv)
    if inner: inner(cv,cx,cy,r)
def hatch_wheel(cv,cx,cy,r):
    for a in range(0,360,4):
        x=cx+math.cos(math.radians(a))*r*0.42;y=cy+math.sin(math.radians(a))*r*0.42;cv.p(int(y),int(x),7)
    for k in range(6):
        a=math.radians(k*60+15)
        for t in range(int(r*0.6)):
            cv.p(int(cy+math.sin(a)*t),int(cx+math.cos(a)*t),15 if t<r*0.3 else 7)
    cv.p(int(cy),int(cx),11)
def eye_inner(cv,cx,cy,r):
    for y in range(int(cy-r*0.5),int(cy+r*0.5)+1):
        for x in range(int(cx-r*0.5),int(cx+r*0.5)+1):
            d=math.hypot((x-cx)/1.0,(y-cy)/0.7)
            if d<r*0.5: cv.p(y,x,3 if d>r*0.35 else 11 if d>r*0.15 else 0)
    cv.p(int(cy-r*0.15),int(cx-r*0.12),15)
def jelly(cv,cx,cy,s,seed):
    S=L()
    for y in range(int(cy-s),int(cy)+1):
        for x in range(int(cx-s*1.2),int(cx+s*1.2)+1):
            if ((x-cx)/(s*1.2))**2+((y-cy)/s)**2<1:
                c=11 if y<cy-s*0.5 else 3 if (x+y)%3 else 9
                if abs(x-cx)<s*0.3 and y>cy-s*0.6: c=0                 # negative-space core
                S.p(y,x,c)
    S.draw(cv,shadow=1)
    for k in range(5): tendril(cv,cx-s+k*s*0.5,cy+1,int(s*1.8),1.2,k+seed,dirx=0,col=3,tip=11)
def ribcage(cv,cx,cy,w,h):
    S=L()
    for k in range(6):
        y=cy-h/2+k*h/6
        for t in range(-w//2,w//2+1):
            yy=y+abs(t)*0.35
            S.p(yy,cx+t,15 if t<0 else 7);S.p(yy+1,cx+t,8)
    for y in range(int(cy-h/2-1),int(cy+h/2+3)): S.p(y,cx,7);S.p(y,cx+1,8)
    S.draw(cv)
def sonar(cv,cx,cy,rmax):
    for r in range(4,rmax,5):
        for a in range(-70,71,3):
            x=cx-math.cos(math.radians(a))*r;y=cy+math.sin(math.radians(a))*r*0.9
            if 0<=int(y)<48 and 0<=int(x)<80 and cv.px[int(y)][int(x)] is None: cv.p(int(y),int(x),3 if r%10 else 11)
def canister(cv,x0,y0,w,h):
    S=L()
    for y in range(h):
        for x in range(w):
            u=x/(w-1);c=[8,7,15,15,7,7,8,1][min(7,int(u*8))]
            if y%5==0: c=8 if c!=15 else 7
            if w*0.3<x<w*0.7 and h*0.25<y<h*0.75: c=11 if (y%2==0) else 3   # glowing salvage core
            if (x==0 or x==w-1) and y%5==2: c=15
            S.p(y0+y,x0+x,c)
    S.draw(cv)
def sub(cv,x0,cy,w,h):
    S=L()
    for y in range(int(cy-h),int(cy+h)+1):
        for x in range(x0,x0+w):
            u=(x-x0)/w;hh=h*(1-((u-0.45)/0.55)**2*0.8)
            if abs(y-cy)>hh: continue
            ny=(y-cy)/h;c=15 if ny<-0.5 else 7 if ny<0 else 8 if ny<0.6 else 1
            if (x-x0)%6==0: c=8
            S.p(y,x,c)
    for k in range(3):
        px=x0+w*0.3+k*w*0.18
        for y in range(int(cy-3),int(cy+2)):
            for x in range(int(px-2),int(px+3)):
                d=math.hypot(x-px,y-cy+0.5)
                if d<2.6: S.p(y,x,11 if d<1.3 else 0)
    for y in range(int(cy-h-4),int(cy-h)+1):
        for x in range(x0+w//3,x0+w//3+6): S.p(y,x,7 if x<x0+w//3+3 else 8)
    S.draw(cv)
    glow(cv,x0-3,cy,4)
def header(cv,title,seed):
    end=B.logo(cv,title.upper(),3,0,TH,slant=False)
    for x in range(W): cv.put(5,x,' ',7)
    cv.put(5,1,'▄▀▄ ',3);cv.put(5,5,title.lower(),15);cv.put(5,5+len(title),' ▀▄▀▄',3)
    for x in range(W): cv.put(6,x,'▀' if x%3 else '▄',[1,1,3,1,8,1,11,1][(x+seed)%8],0)
P22='arrows move, Enter picks, or press the key'
# ---------------- compositions ----------------
def kelp(cv,seed,x0=46,x1=78):
    r=random.Random(seed)
    for k in range(5):
        tendril(cv,r.randint(x0,x1),46,r.randint(10,22),1.5,k+seed,dirx=0,diry=-1,col=8,tip=3)
def c_angler(s,cx,cy,face=-1):
    def f(cv,seed):
        kelp(cv,seed,2,78);angler(cv,cx,cy,s,face,seed);bubbles(cv,cx+s,cy-s,5,seed)
    return f
def c_port_eye(cv,seed):
    kelp(cv,seed,2,78);porthole(cv,62,28,14,eye_inner);bubbles(cv,46,40,6,seed)
    for k in range(3): tendril(cv,48+k*12,44,10,1,k,dirx=0,diry=-1,col=8,tip=11)
def c_helmet(cv,seed):
    kelp(cv,seed,2,78);
    S=L()
    for y in range(14,44):
        for x in range(46,79):
            d=math.hypot(x-62,(y-28)*1.0)
            if d<15: S.p(y,x,15 if (x+y)<82 else 7 if d<12 else 8)
    S.draw(cv);porthole(cv,62,28,9,eye_inner)
    for y in range(40,46):
        for x in range(50,75): cv.p(y,x,[7,8,7,8,1,0][y-40])
def c_hatch(cv,seed):
    kelp(cv,seed);porthole(cv,62,29,13,hatch_wheel);bubbles(cv,76,40,6,seed)
def c_sonar(cv,seed):
    sonar(cv,78,30,32);ribcage(cv,63,29,22,20)
def c_canister(cv,seed):
    kelp(cv,seed);canister(cv,54,15,16,28);bubbles(cv,62,15,4,seed)
    for k in range(2): tendril(cv,52+k*20,46,24,2,k,dirx=0,diry=-1,col=8,tip=3)
def c_jellies(cv,seed):
    jelly(cv,54,22,5,seed);jelly(cv,70,18,6,seed+1);jelly(cv,64,34,4,seed+2)
def c_sub(cv,seed):
    kelp(cv,seed,2,78);sub(cv,44,30,34,8);bubbles(cv,46,26,6,seed)
def c_school(cv,seed):
    kelp(cv,seed)
    for i in range(2):
        for j in range(2): porthole(cv,55+j*15,21+i*15,6,eye_inner if (i+j)%2==0 else hatch_wheel)
SCREENS=[
 ('03_sea_axis_welcome','axis',c_angler(9,57,30),[(12,4,7,'The shop is open.')],'cb1c59ea6aaa09f8f5793f5404c1c0bb5773b2b4c7d712f24be3e0da4f3a1de4'),
 ('04_sea_axis_main_menu','axis',c_angler(8,64,30),[(22,4,8,P22)],'f3d3cc8dd78f2b12d5c26cd5887d0b44015c0385cae8f66508fd182b8921db78'),
 ('05_sea_login','login',c_port_eye,[(12,4,7,'Handle:   |{P}'),(14,4,7,'Password: |{O}')],'71ef04caf75378d980e20055076dfa8c6cfd019bb4ea1be8f2b062ab8abac12f'),
 ('06_sea_apply_new_user','apply',c_helmet,[(12,4,7,'A new account waits on the sysop.')],'0767d92bb5d22d7184a39ce3bc1d3ccbcfa91a808ac2744521b0758e57481d3e'),
 ('07_sea_doors_menu','doors',c_hatch,[(22,4,8,P22)],'a09f1cd3f4ce829a9d313e4cdb6f1ee0b8bbd04da7703adc80c8805210f7debc'),
 ('08_sea_messages_menu','msgs',c_sonar,[(22,4,8,P22)],'c2daba9287b991057d502bdef1c40cd2fe91c36cfd863be63a2d39a1b64db57d'),
 ('09_sea_files_menu','files',c_canister,[(22,4,8,P22)],'2d58c10a3c21544e4a9e8ae8c537d11d7c67cdb8386057c804f6b6a365470678'),
 ('10_sea_matrix_menu','matrix',c_school,[(22,4,8,P22)],'b8da032dfd89172c621ed48d7d8472969c968907f0eec0c54648eb1c8a0c7d84'),
 ('11_sea_fast_menu','fast',c_jellies,[(22,4,8,P22)],'3dd6605a2cc7181a4d15a105f4ed4a567db67cfc7d2988b3f060c9d2ef609264'),
 ('12_sea_shop_screen','shop',c_sub,[(12,4,7,'The spindle is warm.')],'3f7f5c88f3eeb6718da48befd9a9c2b82fa944dc8d188106b4928783d09a51f1'),
 ('13_sea_mill_screen','mill',c_angler(11,56,31,-1),[(12,4,7,'Mind the chips.')],'f3ae563261b15537b8d95c521737aa93798209bb6e67a37340cfc8b4a9cbc855'),
]
def tail(texts):
    t='\x1b[6;51H\x1b[0;1;37m%BN  \x1b[0;1;30mn\x1b[0;1;36mod\x1b[0;1;30me \x1b[0;1;37m%NN\x1b[0m'
    for (r,c,fg,s) in texts: t+='\x1b[%d;%dH\x1b[0;%s3%dm%s'%(r,c,'1;' if fg>7 else '',B.V2A[fg&7],s)
    return t
def check(g):
    for row in g:
        for ch,fg,bg in row: assert fg in ALLOWED and bg in {0,1,3,7}, (ch,fg,bg)
def screen(i,title,comp,texts,menu):
    seed=i*13+2;cv=B.Canvas(24,depth(seed))
    header(cv,title,seed);comp(cv,seed)
    if menu: bezel_window(cv,8,20,3,43);cv.clear(21,21,3,45)
    else:
        rows=[r for r,*_ in texts];w=max(len(t) for *_,t in texts)+(26 if 'Handle' in texts[0][3] else 3)
        bezel_window(cv,min(rows)-1,max(rows)-1,3,3+w)
    for x in range(W): cv.put(23,x,' ',7)
    cv.put(23,1,'░▒▓',1);cv.put(23,22,'A X I S   M I C R O   B B S',7);cv.put(23,52,'u.g. cnc',8);cv.put(23,76,'▓▒░',1)
    return cv
def build():
    os.makedirs(OUT,exist_ok=True);man=[]
    cv=B.Canvas(24,lambda x,y:(' ',7,0) if y<5 else depth(3)(x,y))
    kelp(cv,4,2,78);kelp(cv,9,2,40)
    angler(cv,46,29,13,-1,7);bubbles(cv,66,22,7,3);bubbles(cv,12,40,6,5)
    B.logo(cv,'AXIS',5,0,TH,sx=3,sy=1)
    cv.clear(22,23,0,79)
    cv.put(22,28,'Axis Micro BBS Firmware',15);cv.put(23,23,'▐ U N D E R G R O U N D   C N C ▌',0,3);cv.put(23,23,'▐',11);cv.put(23,55,'▌',11)
    g=cv.final();check(g)
    open(os.path.join(OUT,'01_sea_splash_fullscreen.ans'),'wb').write(B.emit(g,True,'\x1b[24;1H'))
    man.append(('01_sea_splash_fullscreen.ans','5bf5217c25c1c2202d17ca900724b42008b566d417a72d1f520a3357143f817f'))
    cv=B.Canvas(12,lambda x,y:(' ',7,0))
    angler(cv,8,10,5,1,2,lure=False);glow(cv,16,4,4);angler(cv,72,10,5,-1,3,lure=False);glow(cv,64,4,4)
    B.logo(cv,'AXIS',17,2,TH,sx=2,sy=2)
    cv.clear(11,11,0,79);cv.put(11,22,'▐  U N D E R G R O U N D    C N C  ▌',0,3);cv.put(11,22,'▐',11);cv.put(11,57,'▌',11)
    g=cv.final();check(g)
    open(os.path.join(OUT,'02_sea_logo_banner_inline.ans'),'wb').write(B.emit(g,False))
    man.append(('02_sea_logo_banner_inline.ans','d98ae22ef9e3024402916b79784ac123d4d6f5d95bffc4739e8d760ca41dce34'))
    for i,(name,title,comp,texts,h) in enumerate(SCREENS):
        cv=screen(i,title,comp,texts,texts[0][0]==22);g=cv.final();check(g)
        open(os.path.join(OUT,name+'.ans'),'wb').write(B.emit(g,True,tail(texts)));man.append((name+'.ans',h))
    return man
if __name__=='__main__':
    for m in build(): print(*m)
