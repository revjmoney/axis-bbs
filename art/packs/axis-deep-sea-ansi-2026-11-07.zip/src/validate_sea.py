import re,sys,os,glob,hashlib,json,subprocess
H=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,H);import render,build_sea as K
A=os.path.join(H,'..','ans');SRC='/home/box/agent-data/agents/877144b7-19a7-492b-93e8-970b36b970ed/attachments/'
def rebuild():
    subprocess.run([sys.executable,os.path.join(H,'build_sea.py')],check=True,capture_output=True)
    return {os.path.basename(f):hashlib.sha256(open(f,'rb').read()).hexdigest() for f in sorted(glob.glob(A+'/*.ans'))}
h1=rebuild();h2=rebuild();MAP=dict(K.build())
def text_at(g,r,c,t): return ''.join(g[r-1][c-1+i][0] for i in range(len(t)) if c-1+i<80)==t
res={'deterministic':h1==h2,'count':len(h1),'sha256':h1,'files':{}}
OKC={0,1,9,3,11,8,7,15}
for n in h1:
    b=open(os.path.join(A,n),'rb').read();s=b.decode('cp437');r={'source_hash':MAP[n]}
    inline='inline' in n;r['cp437_roundtrip']=s.encode('cp437')==b
    r['ctrl_ok']=not [c for c in s if ord(c)<32 and c not in '\x1b\r\n']
    esc=[m.start() for m in re.finditer('\x1b',s)];seqs=re.findall(r'\x1b\[([0-9;]*)([A-Za-z])',s)
    r['malformed_esc']=len(esc)-len(seqs);kinds={k for _,k in seqs};r['csi_ok']=kinds<=({'m'} if inline else {'m','H','J'})
    sg={int(v) for p,k in seqs if k=='m' for v in p.split(';') if v};r['sgr_ok']=sg<={0,1,30,34,36,37,40,44,46,47}
    g,my,cur,w=render.emulate(b,rows=25);r['no_scroll_25']=not w and len(render.emulate.scrollback)==0
    r['palette_ok']=all(f in OKC and bg in OKC for row in g for _,f,bg in row)
    r['end_cursor']=[cur[0]+1,cur[1]+1]
    ob=open(SRC+MAP[n]+'.ans','rb').read();o=ob.decode('cp437');og,_,oc,_=render.emulate(ob,rows=40)
    pl=re.findall(r'\x1b\[(\d+);(\d+)H(?:\x1b\[[0-9;]*m)*([^\x1b]+)',o)
    r['placements_at_coords']=all(text_at(g,int(a),int(c),t) for a,c,t in pl)
    mac=[(y+1,''.join(ch for ch,_,_ in row).find('%BN')+1) for y,row in enumerate(og) if '%BN' in ''.join(ch for ch,_,_ in row)]
    r['macros_at_source_coords']=all(text_at(g,y,c,'%BN  node %NN') for y,c in mac)
    if pl: r['end_cursor_matches_source']=[oc[0]+1,oc[1]+1]==r['end_cursor']
    if pl and pl[-1][0]=='22':
        r['menu_window_rows9_21_cols4_44_blank']=all(g[y][x][0]==' ' and g[y][x][2]==0 for y in range(8,21) for x in range(3,44))
    res['files'][n]=r
print(json.dumps(res,indent=1,ensure_ascii=False))
